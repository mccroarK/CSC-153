﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HelperLibrary;

/*
* 5/2/2023
* CSC 153
* Kevin McCroary
* Program that will calculate the area for a circle, rectangle, and cylinder using the Calculate method from the Area class.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        // Use variable for switch statement
        string shapeInput = "circle";

        public Form1()
        {
            InitializeComponent();
        }

        private void changeLabels()
        {
            // Change text of instruction labels
            if (shapeInput == "rectangle")
            {
                instructLabel1.Text = "width (int)";
                instructLabel2.Text = "length (int)";
            }
            else
            {
                instructLabel1.Text = "radius (double)";
                instructLabel2.Text = "height (double)";
            }

            // Disable second box if calculating a circle
            if (shapeInput == "circle")
            {
                inputTextBox2.ReadOnly = true;
            }
            else
            {
                inputTextBox2.ReadOnly = false;
            }
        }

        private void circleButton_Click(object sender, EventArgs e)
        {
            shapeInput = "circle";
            changeLabels();
            inputTextBox1.Focus();
        }

        private void rectangleButton_Click(object sender, EventArgs e)
        {
            shapeInput = "rectangle";
            changeLabels();
            inputTextBox1.Focus();
        }

        private void cylinderButton_Click(object sender, EventArgs e)
        {
            shapeInput = "cylinder";
            changeLabels();
            inputTextBox1.Focus();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            try
            {
                switch (shapeInput)
                {
                    case "circle":
                        MessageBox.Show(Area.Calculate(double.Parse(inputTextBox1.Text)).ToString());
                        break;
                    case "rectangle":
                        MessageBox.Show(Area.Calculate(int.Parse(inputTextBox1.Text), int.Parse(inputTextBox2.Text)).ToString());
                        break;
                    case "cylinder":
                        MessageBox.Show(Area.Calculate(double.Parse(inputTextBox1.Text), double.Parse(inputTextBox2.Text)).ToString());
                        break;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid input");
            }

            // Clear and focus
            inputTextBox1.Clear();
            inputTextBox2.Clear();

            inputTextBox1.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            changeLabels();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}