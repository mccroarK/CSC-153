﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLibrary
{
    public class Area
    {
        public static double Calculate(double radius)
        {
            // Area for circle
            return Math.PI * (radius * radius);
        }

        public static double Calculate(int width, int length)
        {
            // Area for rectangle
            return width * length;
        }

        public static double Calculate(double radius, double height)
        {
            // Area for Cylinder
            return Math.PI * (radius * radius) * height;
        }
    }
}
