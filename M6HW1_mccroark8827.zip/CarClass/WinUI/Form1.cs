﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarLibrary;

/*
* 4/24/2023
* CSC 153
* Kevin McCroary
* Allows user to enter a car year and make, build a car, and then accelerate and break the car.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        Car userCar;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buildButton_Click(object sender, EventArgs e)
        {
            int carYear;

            // If user enters info, create a Car object
            if (int.TryParse(yearTextBox.Text, out carYear) && makeTextBox.Text != "")
            {
                userCar = new Car(carYear, makeTextBox.Text);
                carPanel.Enabled = true;

                // Display information to labels
                carShowLabel.Text = yearTextBox.Text + " " + makeTextBox.Text;
                speedShowLabel.Text = userCar.Speed.ToString();
            }
            // Clear
            yearTextBox.Clear();
            makeTextBox.Clear();
        }

        private void breakButton_Click(object sender, EventArgs e)
        {
            // Use the car Break function
            userCar.Break();
            // Show speed
            speedShowLabel.Text = userCar.Speed.ToString();
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            // Use the car Accelerate function
            userCar.Accelerate();
            // Show speed
            speedShowLabel.Text = userCar.Speed.ToString();
        }
    }
}
