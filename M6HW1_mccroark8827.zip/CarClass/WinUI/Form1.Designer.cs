﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.carPanel = new System.Windows.Forms.Panel();
            this.exitButton = new System.Windows.Forms.Button();
            this.buildButton = new System.Windows.Forms.Button();
            this.yearLabel = new System.Windows.Forms.Label();
            this.makeLabel = new System.Windows.Forms.Label();
            this.yearTextBox = new System.Windows.Forms.TextBox();
            this.makeTextBox = new System.Windows.Forms.TextBox();
            this.carLabel = new System.Windows.Forms.Label();
            this.speedLabel = new System.Windows.Forms.Label();
            this.accelerateButton = new System.Windows.Forms.Button();
            this.breakButton = new System.Windows.Forms.Button();
            this.carShowLabel = new System.Windows.Forms.Label();
            this.speedShowLabel = new System.Windows.Forms.Label();
            this.helpLabel = new System.Windows.Forms.Label();
            this.carPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // carPanel
            // 
            this.carPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.carPanel.Controls.Add(this.speedShowLabel);
            this.carPanel.Controls.Add(this.carShowLabel);
            this.carPanel.Controls.Add(this.breakButton);
            this.carPanel.Controls.Add(this.accelerateButton);
            this.carPanel.Controls.Add(this.speedLabel);
            this.carPanel.Controls.Add(this.carLabel);
            this.carPanel.Enabled = false;
            this.carPanel.Location = new System.Drawing.Point(12, 144);
            this.carPanel.Name = "carPanel";
            this.carPanel.Size = new System.Drawing.Size(337, 68);
            this.carPanel.TabIndex = 3;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(274, 231);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // buildButton
            // 
            this.buildButton.Location = new System.Drawing.Point(152, 103);
            this.buildButton.Name = "buildButton";
            this.buildButton.Size = new System.Drawing.Size(75, 23);
            this.buildButton.TabIndex = 2;
            this.buildButton.Text = "Build";
            this.buildButton.UseVisualStyleBackColor = true;
            this.buildButton.Click += new System.EventHandler(this.buildButton_Click);
            // 
            // yearLabel
            // 
            this.yearLabel.Location = new System.Drawing.Point(88, 45);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(100, 23);
            this.yearLabel.TabIndex = 3;
            this.yearLabel.Text = "Car Year:";
            this.yearLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // makeLabel
            // 
            this.makeLabel.Location = new System.Drawing.Point(88, 77);
            this.makeLabel.Name = "makeLabel";
            this.makeLabel.Size = new System.Drawing.Size(100, 23);
            this.makeLabel.TabIndex = 3;
            this.makeLabel.Text = "Car Make:";
            this.makeLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // yearTextBox
            // 
            this.yearTextBox.Location = new System.Drawing.Point(194, 42);
            this.yearTextBox.Name = "yearTextBox";
            this.yearTextBox.Size = new System.Drawing.Size(82, 22);
            this.yearTextBox.TabIndex = 0;
            // 
            // makeTextBox
            // 
            this.makeTextBox.Location = new System.Drawing.Point(194, 74);
            this.makeTextBox.Name = "makeTextBox";
            this.makeTextBox.Size = new System.Drawing.Size(82, 22);
            this.makeTextBox.TabIndex = 1;
            // 
            // carLabel
            // 
            this.carLabel.Location = new System.Drawing.Point(3, 9);
            this.carLabel.Name = "carLabel";
            this.carLabel.Size = new System.Drawing.Size(40, 22);
            this.carLabel.TabIndex = 0;
            this.carLabel.Text = "Car:";
            this.carLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // speedLabel
            // 
            this.speedLabel.Location = new System.Drawing.Point(3, 39);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(40, 22);
            this.speedLabel.TabIndex = 2;
            this.speedLabel.Text = "Mph:";
            // 
            // accelerateButton
            // 
            this.accelerateButton.Location = new System.Drawing.Point(219, 37);
            this.accelerateButton.Name = "accelerateButton";
            this.accelerateButton.Size = new System.Drawing.Size(100, 23);
            this.accelerateButton.TabIndex = 1;
            this.accelerateButton.Text = "Accelerate";
            this.accelerateButton.UseVisualStyleBackColor = true;
            this.accelerateButton.Click += new System.EventHandler(this.accelerateButton_Click);
            // 
            // breakButton
            // 
            this.breakButton.Location = new System.Drawing.Point(97, 37);
            this.breakButton.Name = "breakButton";
            this.breakButton.Size = new System.Drawing.Size(100, 23);
            this.breakButton.TabIndex = 0;
            this.breakButton.Text = "Break";
            this.breakButton.UseVisualStyleBackColor = true;
            this.breakButton.Click += new System.EventHandler(this.breakButton_Click);
            // 
            // carShowLabel
            // 
            this.carShowLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.carShowLabel.Location = new System.Drawing.Point(49, 8);
            this.carShowLabel.Name = "carShowLabel";
            this.carShowLabel.Size = new System.Drawing.Size(270, 22);
            this.carShowLabel.TabIndex = 6;
            this.carShowLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // speedShowLabel
            // 
            this.speedShowLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.speedShowLabel.Location = new System.Drawing.Point(49, 38);
            this.speedShowLabel.Name = "speedShowLabel";
            this.speedShowLabel.Size = new System.Drawing.Size(38, 22);
            this.speedShowLabel.TabIndex = 7;
            this.speedShowLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // helpLabel
            // 
            this.helpLabel.AutoSize = true;
            this.helpLabel.Location = new System.Drawing.Point(12, 9);
            this.helpLabel.Name = "helpLabel";
            this.helpLabel.Size = new System.Drawing.Size(340, 17);
            this.helpLabel.TabIndex = 5;
            this.helpLabel.Text = "Enter a year and make to build a car, then test it out.";
            // 
            // Form1
            // 
            this.AcceptButton = this.buildButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(361, 266);
            this.Controls.Add(this.helpLabel);
            this.Controls.Add(this.makeTextBox);
            this.Controls.Add(this.yearTextBox);
            this.Controls.Add(this.makeLabel);
            this.Controls.Add(this.yearLabel);
            this.Controls.Add(this.buildButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.carPanel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.carPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel carPanel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button buildButton;
        private System.Windows.Forms.Button breakButton;
        private System.Windows.Forms.Button accelerateButton;
        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.Label carLabel;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.Label makeLabel;
        private System.Windows.Forms.TextBox yearTextBox;
        private System.Windows.Forms.TextBox makeTextBox;
        private System.Windows.Forms.Label speedShowLabel;
        private System.Windows.Forms.Label carShowLabel;
        private System.Windows.Forms.Label helpLabel;
    }
}

