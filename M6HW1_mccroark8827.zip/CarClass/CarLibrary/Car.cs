﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
    public class Car
    {
        // Variables
        private int _year;
        private string _make;
        private int _speed;

        // Properties
        public int Year { get {return _year;} set {_year = value;} }
        public string Make { get {return _make;} set {_make = value;} }
        public int Speed { get {return _speed;} set {_speed = value;} }
        public Car(int year, string make)
        {
            // Change car year, make, and speed
            Year = year;
            Make = make;
            Speed = 0;
        }

        public void Accelerate()
        {
            // Add 5 to speed
            Speed += 5;
        }

        public void Break()
        {
            // Take 5 from speed
            Speed -= 5;
            SpeedClamp();
        }

        public void SpeedClamp()
        {
            // Cap speed from going below 0 for immersion
            if (Speed < 0)
            {
                Speed = 0;
            }
        }
    }
}
