﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 2/27/2023
* CSC 153
* Kevin McCroary
* Calculate the amount of money Susan will make if she is paid in incremental amounts for a user inputted day.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            // Accumulator
            int daysToWork;
            // Money variables
            decimal payAmount = 0.01m;
            decimal payTotal = 0.00m;

            // Empty payment display list
            displayListBox.Items.Clear();

            // Check user input
            if (int.TryParse(daysTextBox.Text, out daysToWork))
            {
                // If user input is valid
                // For loop for payment
                for (int i = 0; i < daysToWork; i++)
                {
                    try
                    {
                        // Pay Susan
                        payTotal += payAmount;
                        // Display payment
                        displayListBox.Items.Add($"Day {i + 1}: Susan is paid {payAmount.ToString("c")}.");
                        // Double amount of next pay
                        payAmount *= 2;
                    } 
                    catch (Exception ex)
                    {
                        // TOO MUCH MONEY
                        MessageBox.Show(ex.Message + " Susan is very rich.");
                        break;
                    }
                }
                // Display total payment
                totalTextBox.Text = payTotal.ToString("c");
            }
            else
            {
                // If user input is invalid
                MessageBox.Show("Please enter a valid integer.");
            }
            // Clear text box and focus
            daysTextBox.Clear();
            daysTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close on Esc or exit button
            this.Close();
        }
    }
}
