﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HelperLibrary;

/*
* 4/15/2023
* CSC 153
* Kevin McCroary
* Displays the amount of times a selected baseball team has won the World Series between 1903 and 2012
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // On close button pressed, close program
            FileAccessor.CloseIt();
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // On load, open team file and add teams to list box
            FileAccessor.OpenIt("Teams.txt");
            teamListBox.DataSource = FileAccessor.ListIt();
            FileAccessor.CloseIt(); // Additional just in case
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            FileAccessor.OpenIt("WorldSeriesWinners.txt");
            // On main button clicked, check selected item and display wins
            int winCount = FileAccessor.CountIt(teamListBox.SelectedItem.ToString());
            MessageBox.Show($"The {teamListBox.SelectedItem.ToString()} have won the World Series {winCount} times between 1903 - 2012");
        }
    }
}
