﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HelperLibrary
{
    public static class FileAccessor
    {
        static StreamReader file;
        public static void OpenIt(string fileName)
        {
            // Open file using file name
            file = File.OpenText(@"..\..\files\" + fileName);
        }

        public static void CloseIt()
        {
            // Close file
            file.Close();
        }

        public static List<string> ListIt()
        {
            // Read file and put items into list
            List<string> itemList = new List<string>();
            while (!file.EndOfStream)
            {
                itemList.Add(file.ReadLine());
            }
            return itemList;
        }

        public static int CountIt(string userInput)
        {
            // Count number of times the user string appears in the list
            string item;
            int count = 0;

            while (!file.EndOfStream)
            {
                item = file.ReadLine();
                if (item == userInput)
                {
                    count++; // Add to count if item matches input
                }
            }

            return count;
        }
    }
}
