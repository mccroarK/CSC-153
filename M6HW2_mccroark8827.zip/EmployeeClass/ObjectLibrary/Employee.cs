﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectLibrary
{
    public class Employee
    {
        #region Properties
        public string Name { get; set; }
        public int IdNumber { get; set; }
        public string Department { get; set; }
        public string Position { get; set; }
        #endregion

        #region Constructors
        // Constructor with name, idnumber, department, and position
        public Employee(string name, int id, string department, string position)
        {
            Name = name;
            IdNumber = id;
            Department = department;
            Position = position;
        }

        // Constructor with name and idnumber
        public Employee(string name, int id)
        {
            Name = name;
            IdNumber = id;
            Department = "";
            Position = "";
        }

        // Default Constructor
        public Employee()
        {
            Name = "";
            IdNumber = 0;
            Department = "";
            Position = "";
        }
        #endregion
    }
}
