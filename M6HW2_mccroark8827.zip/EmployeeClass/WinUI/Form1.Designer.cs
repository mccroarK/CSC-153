﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.nameLabel3 = new System.Windows.Forms.Label();
            this.idLabel3 = new System.Windows.Forms.Label();
            this.departmentLabel3 = new System.Windows.Forms.Label();
            this.positionLabel3 = new System.Windows.Forms.Label();
            this.nameLabel2 = new System.Windows.Forms.Label();
            this.idLabel2 = new System.Windows.Forms.Label();
            this.departmentLabel2 = new System.Windows.Forms.Label();
            this.positionLabel2 = new System.Windows.Forms.Label();
            this.positionLabel1 = new System.Windows.Forms.Label();
            this.departmentLabel1 = new System.Windows.Forms.Label();
            this.idLabel1 = new System.Windows.Forms.Label();
            this.positionHeader = new System.Windows.Forms.Label();
            this.departmentHeader = new System.Windows.Forms.Label();
            this.nameHeader = new System.Windows.Forms.Label();
            this.idHeader = new System.Windows.Forms.Label();
            this.nameLabel1 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.nameLabel3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.idLabel3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.departmentLabel3, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.positionLabel3, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.nameLabel2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.idLabel2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.departmentLabel2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.positionLabel2, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.positionLabel1, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.departmentLabel1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.idLabel1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.positionHeader, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.departmentHeader, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.nameHeader, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.idHeader, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.nameLabel1, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 48);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(619, 166);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // nameLabel3
            // 
            this.nameLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel3.Location = new System.Drawing.Point(5, 125);
            this.nameLabel3.Name = "nameLabel3";
            this.nameLabel3.Size = new System.Drawing.Size(146, 39);
            this.nameLabel3.TabIndex = 15;
            this.nameLabel3.Text = "name3";
            this.nameLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // idLabel3
            // 
            this.idLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idLabel3.Location = new System.Drawing.Point(159, 125);
            this.idLabel3.Name = "idLabel3";
            this.idLabel3.Size = new System.Drawing.Size(146, 39);
            this.idLabel3.TabIndex = 14;
            this.idLabel3.Text = "id3";
            this.idLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // departmentLabel3
            // 
            this.departmentLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.departmentLabel3.Location = new System.Drawing.Point(313, 125);
            this.departmentLabel3.Name = "departmentLabel3";
            this.departmentLabel3.Size = new System.Drawing.Size(146, 39);
            this.departmentLabel3.TabIndex = 13;
            this.departmentLabel3.Text = "department3";
            this.departmentLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // positionLabel3
            // 
            this.positionLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.positionLabel3.Location = new System.Drawing.Point(467, 125);
            this.positionLabel3.Name = "positionLabel3";
            this.positionLabel3.Size = new System.Drawing.Size(146, 39);
            this.positionLabel3.TabIndex = 12;
            this.positionLabel3.Text = "position3";
            this.positionLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nameLabel2
            // 
            this.nameLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel2.Location = new System.Drawing.Point(5, 84);
            this.nameLabel2.Name = "nameLabel2";
            this.nameLabel2.Size = new System.Drawing.Size(146, 39);
            this.nameLabel2.TabIndex = 11;
            this.nameLabel2.Text = "name2";
            this.nameLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // idLabel2
            // 
            this.idLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idLabel2.Location = new System.Drawing.Point(159, 84);
            this.idLabel2.Name = "idLabel2";
            this.idLabel2.Size = new System.Drawing.Size(146, 39);
            this.idLabel2.TabIndex = 10;
            this.idLabel2.Text = "id2";
            this.idLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // departmentLabel2
            // 
            this.departmentLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.departmentLabel2.Location = new System.Drawing.Point(313, 84);
            this.departmentLabel2.Name = "departmentLabel2";
            this.departmentLabel2.Size = new System.Drawing.Size(146, 39);
            this.departmentLabel2.TabIndex = 9;
            this.departmentLabel2.Text = "department2";
            this.departmentLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // positionLabel2
            // 
            this.positionLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.positionLabel2.Location = new System.Drawing.Point(467, 84);
            this.positionLabel2.Name = "positionLabel2";
            this.positionLabel2.Size = new System.Drawing.Size(146, 39);
            this.positionLabel2.TabIndex = 8;
            this.positionLabel2.Text = "position2";
            this.positionLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // positionLabel1
            // 
            this.positionLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.positionLabel1.Location = new System.Drawing.Point(467, 43);
            this.positionLabel1.Name = "positionLabel1";
            this.positionLabel1.Size = new System.Drawing.Size(146, 39);
            this.positionLabel1.TabIndex = 7;
            this.positionLabel1.Text = "position1";
            this.positionLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // departmentLabel1
            // 
            this.departmentLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.departmentLabel1.Location = new System.Drawing.Point(313, 43);
            this.departmentLabel1.Name = "departmentLabel1";
            this.departmentLabel1.Size = new System.Drawing.Size(146, 39);
            this.departmentLabel1.TabIndex = 6;
            this.departmentLabel1.Text = "department1";
            this.departmentLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // idLabel1
            // 
            this.idLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idLabel1.Location = new System.Drawing.Point(159, 43);
            this.idLabel1.Name = "idLabel1";
            this.idLabel1.Size = new System.Drawing.Size(146, 39);
            this.idLabel1.TabIndex = 5;
            this.idLabel1.Text = "id1";
            this.idLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // positionHeader
            // 
            this.positionHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.positionHeader.Location = new System.Drawing.Point(467, 2);
            this.positionHeader.Name = "positionHeader";
            this.positionHeader.Size = new System.Drawing.Size(146, 39);
            this.positionHeader.TabIndex = 3;
            this.positionHeader.Text = "Position";
            this.positionHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // departmentHeader
            // 
            this.departmentHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.departmentHeader.Location = new System.Drawing.Point(313, 2);
            this.departmentHeader.Name = "departmentHeader";
            this.departmentHeader.Size = new System.Drawing.Size(146, 39);
            this.departmentHeader.TabIndex = 2;
            this.departmentHeader.Text = "Department";
            this.departmentHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nameHeader
            // 
            this.nameHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameHeader.Location = new System.Drawing.Point(5, 2);
            this.nameHeader.Name = "nameHeader";
            this.nameHeader.Size = new System.Drawing.Size(146, 39);
            this.nameHeader.TabIndex = 0;
            this.nameHeader.Text = "Name";
            this.nameHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // idHeader
            // 
            this.idHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idHeader.Location = new System.Drawing.Point(159, 2);
            this.idHeader.Name = "idHeader";
            this.idHeader.Size = new System.Drawing.Size(146, 39);
            this.idHeader.TabIndex = 1;
            this.idHeader.Text = "ID Number";
            this.idHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nameLabel1
            // 
            this.nameLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel1.Location = new System.Drawing.Point(5, 43);
            this.nameLabel1.Name = "nameLabel1";
            this.nameLabel1.Size = new System.Drawing.Size(146, 39);
            this.nameLabel1.TabIndex = 4;
            this.nameLabel1.Text = "name1";
            this.nameLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // exitButton
            // 
            this.exitButton.AutoSize = true;
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(565, 220);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(66, 27);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(135, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(372, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Makes employee objects and displays them to the screen.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(643, 259);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Employee Class";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label nameLabel3;
        private System.Windows.Forms.Label idLabel3;
        private System.Windows.Forms.Label departmentLabel3;
        private System.Windows.Forms.Label positionLabel3;
        private System.Windows.Forms.Label nameLabel2;
        private System.Windows.Forms.Label idLabel2;
        private System.Windows.Forms.Label departmentLabel2;
        private System.Windows.Forms.Label positionLabel2;
        private System.Windows.Forms.Label positionLabel1;
        private System.Windows.Forms.Label departmentLabel1;
        private System.Windows.Forms.Label idLabel1;
        private System.Windows.Forms.Label positionHeader;
        private System.Windows.Forms.Label departmentHeader;
        private System.Windows.Forms.Label nameHeader;
        private System.Windows.Forms.Label idHeader;
        private System.Windows.Forms.Label nameLabel1;
        private System.Windows.Forms.Label label1;
    }
}

