﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ObjectLibrary;

/*
* 2/26/2023
* CSC 153
* Kevin McCroary
* Program that makes 3 employees and displays them to a table
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Arrays of labels
            Label[] names = {nameLabel1, nameLabel2, nameLabel3};
            Label[] ids = {idLabel1, idLabel2, idLabel3};
            Label[] departments = {departmentLabel1, departmentLabel2, departmentLabel3};
            Label[] positions = {positionLabel1, positionLabel2, positionLabel3};

            // Array of Employees
            Employee[] employees = { new Employee("Susan Mayers", 47899, "Accounting", "Vice President"), new Employee("Mark Jones", 39119, "IT", "Programmer"), new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer") };

            // Display all properties into labels
            for (int i = 0; i < employees.Length; i++)
            {
                names[i].Text = employees[i].Name;
                ids[i].Text = employees[i].IdNumber.ToString();
                departments[i].Text = employees[i].Department;
                positions[i].Text = employees[i].Position;
            }
        }
    }
}
