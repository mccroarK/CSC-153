﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 1/31/2023
* CSC 153
* Kevin McCroary
* Calculates a property's tax rate using user input for the property value.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        const decimal TAXRATE = 0.64m;
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            // tax rate = .64
            try
            {
                // Converts property value and tax rate to decimals
                // tax = (property value / 100) * tax rate
                taxDisplayLabel.Text = ((Decimal.Parse(propertyValueTextBox.Text) / 100) * TAXRATE).ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            // Clear property value box
            propertyValueTextBox.Clear();
            propertyValueTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
