﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionLabel = new System.Windows.Forms.Label();
            this.taxBelowLabel = new System.Windows.Forms.Label();
            this.taxDisplayLabel = new System.Windows.Forms.Label();
            this.propertyValueTextBox = new System.Windows.Forms.TextBox();
            this.inputBelowLabel = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // instructionLabel
            // 
            this.instructionLabel.Location = new System.Drawing.Point(12, 9);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(333, 26);
            this.instructionLabel.TabIndex = 3;
            this.instructionLabel.Text = "Input your property\'s value to get the property tax.";
            this.instructionLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // taxBelowLabel
            // 
            this.taxBelowLabel.AutoSize = true;
            this.taxBelowLabel.Location = new System.Drawing.Point(44, 182);
            this.taxBelowLabel.Name = "taxBelowLabel";
            this.taxBelowLabel.Size = new System.Drawing.Size(35, 17);
            this.taxBelowLabel.TabIndex = 5;
            this.taxBelowLabel.Text = "Tax:";
            this.taxBelowLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // taxDisplayLabel
            // 
            this.taxDisplayLabel.AutoSize = true;
            this.taxDisplayLabel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.taxDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxDisplayLabel.Location = new System.Drawing.Point(47, 199);
            this.taxDisplayLabel.MinimumSize = new System.Drawing.Size(263, 22);
            this.taxDisplayLabel.Name = "taxDisplayLabel";
            this.taxDisplayLabel.Size = new System.Drawing.Size(263, 22);
            this.taxDisplayLabel.TabIndex = 6;
            this.taxDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // propertyValueTextBox
            // 
            this.propertyValueTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.propertyValueTextBox.Location = new System.Drawing.Point(47, 91);
            this.propertyValueTextBox.MinimumSize = new System.Drawing.Size(263, 22);
            this.propertyValueTextBox.Name = "propertyValueTextBox";
            this.propertyValueTextBox.Size = new System.Drawing.Size(263, 22);
            this.propertyValueTextBox.TabIndex = 0;
            this.propertyValueTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // inputBelowLabel
            // 
            this.inputBelowLabel.AutoSize = true;
            this.inputBelowLabel.Location = new System.Drawing.Point(44, 71);
            this.inputBelowLabel.Name = "inputBelowLabel";
            this.inputBelowLabel.Size = new System.Drawing.Size(106, 17);
            this.inputBelowLabel.TabIndex = 4;
            this.inputBelowLabel.Text = "Property Value:";
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(133, 131);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(88, 26);
            this.calcButton.TabIndex = 1;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(259, 245);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(86, 26);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 277);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.inputBelowLabel);
            this.Controls.Add(this.propertyValueTextBox);
            this.Controls.Add(this.taxDisplayLabel);
            this.Controls.Add(this.taxBelowLabel);
            this.Controls.Add(this.instructionLabel);
            this.Name = "Form1";
            this.Text = "Property Tax Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label taxBelowLabel;
        private System.Windows.Forms.Label taxDisplayLabel;
        private System.Windows.Forms.TextBox propertyValueTextBox;
        private System.Windows.Forms.Label inputBelowLabel;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Button exitButton;
    }
}

