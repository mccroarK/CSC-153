﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.color1Group = new System.Windows.Forms.GroupBox();
            this.red1Button = new System.Windows.Forms.RadioButton();
            this.blue1Button = new System.Windows.Forms.RadioButton();
            this.yellow1Button = new System.Windows.Forms.RadioButton();
            this.color2Group = new System.Windows.Forms.GroupBox();
            this.yellow2Button = new System.Windows.Forms.RadioButton();
            this.blue2Button = new System.Windows.Forms.RadioButton();
            this.red2Button = new System.Windows.Forms.RadioButton();
            this.tipLabel = new System.Windows.Forms.Label();
            this.mixButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.color1Group.SuspendLayout();
            this.color2Group.SuspendLayout();
            this.SuspendLayout();
            // 
            // color1Group
            // 
            this.color1Group.Controls.Add(this.yellow1Button);
            this.color1Group.Controls.Add(this.blue1Button);
            this.color1Group.Controls.Add(this.red1Button);
            this.color1Group.Location = new System.Drawing.Point(12, 49);
            this.color1Group.Name = "color1Group";
            this.color1Group.Size = new System.Drawing.Size(209, 134);
            this.color1Group.TabIndex = 0;
            this.color1Group.TabStop = false;
            this.color1Group.Text = "Select the First Color";
            // 
            // red1Button
            // 
            this.red1Button.AutoSize = true;
            this.red1Button.Location = new System.Drawing.Point(31, 34);
            this.red1Button.Name = "red1Button";
            this.red1Button.Size = new System.Drawing.Size(55, 21);
            this.red1Button.TabIndex = 0;
            this.red1Button.TabStop = true;
            this.red1Button.Text = "Red";
            this.red1Button.UseVisualStyleBackColor = true;
            // 
            // blue1Button
            // 
            this.blue1Button.AutoSize = true;
            this.blue1Button.Location = new System.Drawing.Point(31, 61);
            this.blue1Button.Name = "blue1Button";
            this.blue1Button.Size = new System.Drawing.Size(57, 21);
            this.blue1Button.TabIndex = 1;
            this.blue1Button.TabStop = true;
            this.blue1Button.Text = "Blue";
            this.blue1Button.UseVisualStyleBackColor = true;
            // 
            // yellow1Button
            // 
            this.yellow1Button.AutoSize = true;
            this.yellow1Button.Location = new System.Drawing.Point(31, 88);
            this.yellow1Button.Name = "yellow1Button";
            this.yellow1Button.Size = new System.Drawing.Size(69, 21);
            this.yellow1Button.TabIndex = 2;
            this.yellow1Button.TabStop = true;
            this.yellow1Button.Text = "Yellow";
            this.yellow1Button.UseVisualStyleBackColor = true;
            // 
            // color2Group
            // 
            this.color2Group.Controls.Add(this.yellow2Button);
            this.color2Group.Controls.Add(this.blue2Button);
            this.color2Group.Controls.Add(this.red2Button);
            this.color2Group.Location = new System.Drawing.Point(241, 49);
            this.color2Group.Name = "color2Group";
            this.color2Group.Size = new System.Drawing.Size(209, 134);
            this.color2Group.TabIndex = 1;
            this.color2Group.TabStop = false;
            this.color2Group.Text = "Select the Second Color";
            // 
            // yellow2Button
            // 
            this.yellow2Button.AutoSize = true;
            this.yellow2Button.Location = new System.Drawing.Point(31, 88);
            this.yellow2Button.Name = "yellow2Button";
            this.yellow2Button.Size = new System.Drawing.Size(69, 21);
            this.yellow2Button.TabIndex = 2;
            this.yellow2Button.TabStop = true;
            this.yellow2Button.Text = "Yellow";
            this.yellow2Button.UseVisualStyleBackColor = true;
            // 
            // blue2Button
            // 
            this.blue2Button.AutoSize = true;
            this.blue2Button.Location = new System.Drawing.Point(31, 61);
            this.blue2Button.Name = "blue2Button";
            this.blue2Button.Size = new System.Drawing.Size(57, 21);
            this.blue2Button.TabIndex = 1;
            this.blue2Button.TabStop = true;
            this.blue2Button.Text = "Blue";
            this.blue2Button.UseVisualStyleBackColor = true;
            // 
            // red2Button
            // 
            this.red2Button.AutoSize = true;
            this.red2Button.Location = new System.Drawing.Point(31, 34);
            this.red2Button.Name = "red2Button";
            this.red2Button.Size = new System.Drawing.Size(55, 21);
            this.red2Button.TabIndex = 0;
            this.red2Button.TabStop = true;
            this.red2Button.Text = "Red";
            this.red2Button.UseVisualStyleBackColor = true;
            // 
            // tipLabel
            // 
            this.tipLabel.AutoSize = true;
            this.tipLabel.Location = new System.Drawing.Point(12, 18);
            this.tipLabel.Name = "tipLabel";
            this.tipLabel.Size = new System.Drawing.Size(438, 17);
            this.tipLabel.TabIndex = 4;
            this.tipLabel.Text = "Select 2 colors and press mix to change the background of the form.";
            // 
            // mixButton
            // 
            this.mixButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mixButton.Location = new System.Drawing.Point(133, 189);
            this.mixButton.Name = "mixButton";
            this.mixButton.Size = new System.Drawing.Size(88, 27);
            this.mixButton.TabIndex = 2;
            this.mixButton.Text = "Mix";
            this.mixButton.UseVisualStyleBackColor = true;
            this.mixButton.Click += new System.EventHandler(this.mixButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitButton.Location = new System.Drawing.Point(241, 189);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(88, 27);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.mixButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(463, 250);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.mixButton);
            this.Controls.Add(this.tipLabel);
            this.Controls.Add(this.color2Group);
            this.Controls.Add(this.color1Group);
            this.Name = "Form1";
            this.Text = "Color Mixer";
            this.color1Group.ResumeLayout(false);
            this.color1Group.PerformLayout();
            this.color2Group.ResumeLayout(false);
            this.color2Group.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox color1Group;
        private System.Windows.Forms.RadioButton yellow1Button;
        private System.Windows.Forms.RadioButton blue1Button;
        private System.Windows.Forms.RadioButton red1Button;
        private System.Windows.Forms.GroupBox color2Group;
        private System.Windows.Forms.RadioButton yellow2Button;
        private System.Windows.Forms.RadioButton blue2Button;
        private System.Windows.Forms.RadioButton red2Button;
        private System.Windows.Forms.Label tipLabel;
        private System.Windows.Forms.Button mixButton;
        private System.Windows.Forms.Button exitButton;
    }
}

