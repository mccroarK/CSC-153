﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 2/6/2023
* CSC 153
* Kevin McCroary
* App that lets a user select two colors, mix them, and change the background color of the form.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
            // If I start both buttons checked, I do not need to make a conditional statement to check the user
            // >:)
            red1Button.Checked = true;
            red2Button.Checked = true;
        }

        private void mixButton_Click(object sender, EventArgs e)
        {
            // Color bools
            bool redCheck = false;
            bool blueCheck = false;
            bool yellowCheck = false;

            // Color check

            // Check if Red is active (Also just figured out a better way to do this)
            if (red1Button.Checked || red2Button.Checked)
            {
                redCheck = true;
            }

            // Check if Blue is active
            if (blue1Button.Checked || blue2Button.Checked)
            {
                blueCheck = true;
            }

            // Check if Yellow is active
            if (yellow1Button.Checked || yellow2Button.Checked)
            {
                yellowCheck = true;
            }

            // Mix colors and change background color

            if (redCheck && blueCheck) {
                // Purple
                this.BackColor = Color.Purple;
            } else if (redCheck && yellowCheck) {
                // Orange
                this.BackColor = Color.Orange;
            } else if (blueCheck && yellowCheck) {
                // Green
                this.BackColor = Color.Green;
            } else {
                // Single Colors
                if (redCheck) {
                    // Red
                    this.BackColor = Color.Red;
                } else if (blueCheck) {
                    // Blue
                    this.BackColor = Color.Blue;
                } else {
                    // Yellow
                    this.BackColor = Color.Yellow;
                }
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
