﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.quarterCountTextBox = new System.Windows.Forms.TextBox();
            this.dimeCountTextBox = new System.Windows.Forms.TextBox();
            this.nickelCountTextBox = new System.Windows.Forms.TextBox();
            this.pennyCountTextBox = new System.Windows.Forms.TextBox();
            this.quarterLabel = new System.Windows.Forms.Label();
            this.dimeLabel = new System.Windows.Forms.Label();
            this.nickelLabel = new System.Windows.Forms.Label();
            this.pennyLabel = new System.Windows.Forms.Label();
            this.guessButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.tipLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.quarterCountTextBox);
            this.panel1.Controls.Add(this.dimeCountTextBox);
            this.panel1.Controls.Add(this.nickelCountTextBox);
            this.panel1.Controls.Add(this.pennyCountTextBox);
            this.panel1.Controls.Add(this.quarterLabel);
            this.panel1.Controls.Add(this.dimeLabel);
            this.panel1.Controls.Add(this.nickelLabel);
            this.panel1.Controls.Add(this.pennyLabel);
            this.panel1.Location = new System.Drawing.Point(13, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(215, 161);
            this.panel1.TabIndex = 0;
            // 
            // quarterCountTextBox
            // 
            this.quarterCountTextBox.Location = new System.Drawing.Point(88, 120);
            this.quarterCountTextBox.Name = "quarterCountTextBox";
            this.quarterCountTextBox.Size = new System.Drawing.Size(102, 22);
            this.quarterCountTextBox.TabIndex = 3;
            // 
            // dimeCountTextBox
            // 
            this.dimeCountTextBox.Location = new System.Drawing.Point(88, 83);
            this.dimeCountTextBox.Name = "dimeCountTextBox";
            this.dimeCountTextBox.Size = new System.Drawing.Size(102, 22);
            this.dimeCountTextBox.TabIndex = 2;
            // 
            // nickelCountTextBox
            // 
            this.nickelCountTextBox.Location = new System.Drawing.Point(88, 49);
            this.nickelCountTextBox.Name = "nickelCountTextBox";
            this.nickelCountTextBox.Size = new System.Drawing.Size(102, 22);
            this.nickelCountTextBox.TabIndex = 1;
            // 
            // pennyCountTextBox
            // 
            this.pennyCountTextBox.Location = new System.Drawing.Point(88, 15);
            this.pennyCountTextBox.Name = "pennyCountTextBox";
            this.pennyCountTextBox.Size = new System.Drawing.Size(102, 22);
            this.pennyCountTextBox.TabIndex = 0;
            // 
            // quarterLabel
            // 
            this.quarterLabel.Location = new System.Drawing.Point(18, 123);
            this.quarterLabel.Name = "quarterLabel";
            this.quarterLabel.Size = new System.Drawing.Size(64, 22);
            this.quarterLabel.TabIndex = 7;
            this.quarterLabel.Text = "Quarters:";
            this.quarterLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // dimeLabel
            // 
            this.dimeLabel.Location = new System.Drawing.Point(18, 86);
            this.dimeLabel.Name = "dimeLabel";
            this.dimeLabel.Size = new System.Drawing.Size(64, 22);
            this.dimeLabel.TabIndex = 6;
            this.dimeLabel.Text = "Dimes:";
            this.dimeLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // nickelLabel
            // 
            this.nickelLabel.Location = new System.Drawing.Point(18, 52);
            this.nickelLabel.Name = "nickelLabel";
            this.nickelLabel.Size = new System.Drawing.Size(64, 22);
            this.nickelLabel.TabIndex = 5;
            this.nickelLabel.Text = "Nickels:";
            this.nickelLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // pennyLabel
            // 
            this.pennyLabel.Location = new System.Drawing.Point(18, 18);
            this.pennyLabel.Name = "pennyLabel";
            this.pennyLabel.Size = new System.Drawing.Size(64, 22);
            this.pennyLabel.TabIndex = 4;
            this.pennyLabel.Text = "Pennies:";
            this.pennyLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // guessButton
            // 
            this.guessButton.Location = new System.Drawing.Point(78, 214);
            this.guessButton.Name = "guessButton";
            this.guessButton.Size = new System.Drawing.Size(75, 23);
            this.guessButton.TabIndex = 1;
            this.guessButton.Text = "Guess";
            this.guessButton.UseVisualStyleBackColor = true;
            this.guessButton.Click += new System.EventHandler(this.guessButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(153, 262);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // tipLabel
            // 
            this.tipLabel.Location = new System.Drawing.Point(13, 9);
            this.tipLabel.Name = "tipLabel";
            this.tipLabel.Size = new System.Drawing.Size(215, 35);
            this.tipLabel.TabIndex = 3;
            this.tipLabel.Text = "Try to match the amount of a dollar.";
            this.tipLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AcceptButton = this.guessButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(240, 297);
            this.Controls.Add(this.tipLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.guessButton);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Change For a Dollar Game";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label quarterLabel;
        private System.Windows.Forms.Label dimeLabel;
        private System.Windows.Forms.Label nickelLabel;
        private System.Windows.Forms.Label pennyLabel;
        private System.Windows.Forms.TextBox quarterCountTextBox;
        private System.Windows.Forms.TextBox dimeCountTextBox;
        private System.Windows.Forms.TextBox nickelCountTextBox;
        private System.Windows.Forms.TextBox pennyCountTextBox;
        private System.Windows.Forms.Button guessButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label tipLabel;
    }
}

