﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 2/6/2023
* CSC 153
* Kevin McCroary
* Allow the user to guess the amount of coins needed to match the value of a dollar.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        private const decimal pennyValue = 0.01m;
        private const decimal nickelValue = 0.05m;
        private const decimal dimeValue = 0.10m;
        private const decimal quarterValue = 0.25m;
        private const decimal dollarValue = 1.00m;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guessButton_Click(object sender, EventArgs e)
        {
            int pennyCount, nickelCount, dimeCount, quarterCount;
            decimal guessValue = 0m;

            // If boxes are empty, default to 0
            if (pennyCountTextBox.Text == "")
            {
                pennyCountTextBox.Text = "0";
            }
            if (nickelCountTextBox.Text == "")
            {
                nickelCountTextBox.Text = "0";
            }
            if (dimeCountTextBox.Text == "")
            {
                dimeCountTextBox.Text = "0";
            }
            if (quarterCountTextBox.Text == "")
            {
                quarterCountTextBox.Text = "0";
            }
            // Check if penny text can be converted to an int
            if (int.TryParse(pennyCountTextBox.Text, out pennyCount))
            {

                // Check if nickel text can be converted to an int
                if (int.TryParse(nickelCountTextBox.Text, out nickelCount))
                {

                    // Check if dime text can be converted to an int
                    if (int.TryParse(dimeCountTextBox.Text, out dimeCount))
                    {

                        // Check if quarter text can be converted to an int
                        if (int.TryParse(quarterCountTextBox.Text, out quarterCount))
                        {
                            // Every box is good
                            guessValue = (pennyCount * pennyValue) + (nickelCount * nickelValue)
                                + (dimeCount * dimeValue) + (quarterCount * quarterValue);

                            // Check guess vs dollar value
                            if (guessValue == dollarValue)
                            {
                                MessageBox.Show("Congratulations, you won.");
                                // Clear boxes
                                pennyCountTextBox.Clear();
                                nickelCountTextBox.Clear();
                                dimeCountTextBox.Clear();
                                quarterCountTextBox.Clear();
                            }
                            // If user is wrong
                            else
                            {
                                if (guessValue > dollarValue)
                                {
                                    MessageBox.Show("Too high, you lose.");
                                }
                                else
                                {
                                    MessageBox.Show("Too low, you lose.");
                                }
                            }
                        }

                        // Quarter text is wrong
                        else
                        {
                            MessageBox.Show("Incorrect input for quarter count.");
                        }
                    }

                    // Dime text is wrong
                    else
                    {
                        MessageBox.Show("Incorrect input for dime count.");
                    }
                }

                // Nickel text is wrong
                else
                {
                    MessageBox.Show("Incorrect input for nickel count.");
                }
            }

            // Penny text is wrong
            else
            {
                MessageBox.Show("Incorrect input for penny count.");
            }
        }
    }
}
