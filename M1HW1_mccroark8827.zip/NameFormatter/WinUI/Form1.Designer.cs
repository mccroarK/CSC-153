﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.previewButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.format1Button = new System.Windows.Forms.Button();
            this.format2Button = new System.Windows.Forms.Button();
            this.format4Button = new System.Windows.Forms.Button();
            this.format3Button = new System.Windows.Forms.Button();
            this.format6Button = new System.Windows.Forms.Button();
            this.format5Button = new System.Windows.Forms.Button();
            this.finalNameLabel = new System.Windows.Forms.Label();
            this.titleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.titleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.enterButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // previewButton
            // 
            this.previewButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.previewButton.Location = new System.Drawing.Point(224, 184);
            this.previewButton.Name = "previewButton";
            this.previewButton.Size = new System.Drawing.Size(91, 28);
            this.previewButton.TabIndex = 4;
            this.previewButton.Text = "Preview";
            this.previewButton.UseVisualStyleBackColor = true;
            this.previewButton.Click += new System.EventHandler(this.previewButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(224, 410);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(91, 28);
            this.clearButton.TabIndex = 13;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // format1Button
            // 
            this.format1Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.format1Button.Location = new System.Drawing.Point(12, 230);
            this.format1Button.Name = "format1Button";
            this.format1Button.Size = new System.Drawing.Size(255, 33);
            this.format1Button.TabIndex = 5;
            this.format1Button.UseVisualStyleBackColor = true;
            this.format1Button.Click += new System.EventHandler(this.format1Button_Click);
            // 
            // format2Button
            // 
            this.format2Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.format2Button.Location = new System.Drawing.Point(273, 230);
            this.format2Button.Name = "format2Button";
            this.format2Button.Size = new System.Drawing.Size(255, 33);
            this.format2Button.TabIndex = 6;
            this.format2Button.UseVisualStyleBackColor = true;
            this.format2Button.Click += new System.EventHandler(this.format2Button_Click);
            // 
            // format4Button
            // 
            this.format4Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.format4Button.Location = new System.Drawing.Point(273, 269);
            this.format4Button.Name = "format4Button";
            this.format4Button.Size = new System.Drawing.Size(255, 33);
            this.format4Button.TabIndex = 8;
            this.format4Button.UseVisualStyleBackColor = true;
            this.format4Button.Click += new System.EventHandler(this.format4Button_Click);
            // 
            // format3Button
            // 
            this.format3Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.format3Button.Location = new System.Drawing.Point(12, 269);
            this.format3Button.Name = "format3Button";
            this.format3Button.Size = new System.Drawing.Size(255, 33);
            this.format3Button.TabIndex = 7;
            this.format3Button.UseVisualStyleBackColor = true;
            this.format3Button.Click += new System.EventHandler(this.format3Button_Click);
            // 
            // format6Button
            // 
            this.format6Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.format6Button.Location = new System.Drawing.Point(273, 308);
            this.format6Button.Name = "format6Button";
            this.format6Button.Size = new System.Drawing.Size(255, 33);
            this.format6Button.TabIndex = 10;
            this.format6Button.UseVisualStyleBackColor = true;
            this.format6Button.Click += new System.EventHandler(this.format6Button_Click);
            // 
            // format5Button
            // 
            this.format5Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.format5Button.Location = new System.Drawing.Point(12, 308);
            this.format5Button.Name = "format5Button";
            this.format5Button.Size = new System.Drawing.Size(255, 33);
            this.format5Button.TabIndex = 9;
            this.format5Button.UseVisualStyleBackColor = true;
            this.format5Button.Click += new System.EventHandler(this.format5Button_Click);
            // 
            // finalNameLabel
            // 
            this.finalNameLabel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.finalNameLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.finalNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.finalNameLabel.Location = new System.Drawing.Point(12, 362);
            this.finalNameLabel.Name = "finalNameLabel";
            this.finalNameLabel.Size = new System.Drawing.Size(516, 32);
            this.finalNameLabel.TabIndex = 11;
            this.finalNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // titleNameLabel
            // 
            this.titleNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleNameLabel.Location = new System.Drawing.Point(12, 137);
            this.titleNameLabel.Name = "titleNameLabel";
            this.titleNameLabel.Size = new System.Drawing.Size(206, 23);
            this.titleNameLabel.TabIndex = 25;
            this.titleNameLabel.Text = "Preferred Title:";
            this.titleNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameLabel.Location = new System.Drawing.Point(12, 104);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(206, 23);
            this.lastNameLabel.TabIndex = 24;
            this.lastNameLabel.Text = "Last Name:";
            this.lastNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middleNameLabel.Location = new System.Drawing.Point(12, 71);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(206, 23);
            this.middleNameLabel.TabIndex = 23;
            this.middleNameLabel.Text = "Middle Name:";
            this.middleNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameLabel.Location = new System.Drawing.Point(12, 38);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(206, 23);
            this.firstNameLabel.TabIndex = 22;
            this.firstNameLabel.Text = "First Name:";
            this.firstNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // titleNameTextBox
            // 
            this.titleNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleNameTextBox.Location = new System.Drawing.Point(224, 137);
            this.titleNameTextBox.Name = "titleNameTextBox";
            this.titleNameTextBox.Size = new System.Drawing.Size(238, 27);
            this.titleNameTextBox.TabIndex = 3;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameTextBox.Location = new System.Drawing.Point(224, 104);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(238, 27);
            this.lastNameTextBox.TabIndex = 2;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middleNameTextBox.Location = new System.Drawing.Point(224, 71);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(238, 27);
            this.middleNameTextBox.TabIndex = 1;
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameTextBox.Location = new System.Drawing.Point(224, 38);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(238, 27);
            this.firstNameTextBox.TabIndex = 0;
            // 
            // enterButton
            // 
            this.enterButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterButton.Location = new System.Drawing.Point(12, 410);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(91, 28);
            this.enterButton.TabIndex = 12;
            this.enterButton.Text = "Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(437, 410);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(91, 28);
            this.exitButton.TabIndex = 26;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.titleNameLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.titleNameTextBox);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.finalNameLabel);
            this.Controls.Add(this.format6Button);
            this.Controls.Add(this.format5Button);
            this.Controls.Add(this.format4Button);
            this.Controls.Add(this.format3Button);
            this.Controls.Add(this.format2Button);
            this.Controls.Add(this.format1Button);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.previewButton);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button previewButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button format1Button;
        private System.Windows.Forms.Button format2Button;
        private System.Windows.Forms.Button format4Button;
        private System.Windows.Forms.Button format3Button;
        private System.Windows.Forms.Button format6Button;
        private System.Windows.Forms.Button format5Button;
        private System.Windows.Forms.Label finalNameLabel;
        private System.Windows.Forms.Label titleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.TextBox titleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Button exitButton;
    }
}

