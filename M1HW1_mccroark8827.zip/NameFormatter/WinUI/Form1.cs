﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 1/20/2023
* CSC 153
* Kevin McCroary
* Program that allows a user to enter their name and preferred title and then arrange then in 6 different formats
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        string firstName;
        string middleName;
        string lastName;
        string titleName;

        public Form1()
        {
            InitializeComponent();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear text boxes
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            titleNameTextBox.Text = "";

            // Clear Buttons
            format1Button.Text = "";
            format2Button.Text = "";
            format3Button.Text = "";
            format4Button.Text = "";
            format5Button.Text = "";
            format6Button.Text = "";

            // Clear final name label
            finalNameLabel.Text = "";
        }

        private void previewButton_Click(object sender, EventArgs e)
        {
            // Changes format button text
            firstName = firstNameTextBox.Text;
            middleName = middleNameTextBox.Text;
            lastName = lastNameTextBox.Text;
            titleName = titleNameTextBox.Text;

            // Format 1: [Title] [First Name] [Middle Name] [Last Name]
            format1Button.Text = titleName + " " + firstName + " " + middleName + " " + lastName;

            // Format 2: [First Name] [Middle Name] [Last Name]
            format2Button.Text = firstName + " " + middleName + " " + lastName;

            // Format 3: [First Name] [Last Name]
            format3Button.Text = firstName + " " + lastName;

            // Format 4: [Last Name], [First Name] [Middle Name], [Title]
            format4Button.Text = lastName + ", " + firstName + " " + middleName + ", " + titleName;

            // Format 5: [Last Name], [First Name] [Middle Name]
            format5Button.Text = lastName + ", " + firstName + " " + middleName;

            // Format 6: [Last Name], [First Name] Also I realize I made a typo in my IPO
            format6Button.Text = lastName + ", " + firstName;
        }

        private void format1Button_Click(object sender, EventArgs e)
        {
            finalNameLabel.Text = format1Button.Text;
        }

        private void format2Button_Click(object sender, EventArgs e)
        {
            finalNameLabel.Text = format2Button.Text;
        }

        private void format3Button_Click(object sender, EventArgs e)
        {
            finalNameLabel.Text = format3Button.Text;
        }

        private void format4Button_Click(object sender, EventArgs e)
        {
            finalNameLabel.Text = format4Button.Text;
        }

        private void format5Button_Click(object sender, EventArgs e)
        {
            finalNameLabel.Text = format5Button.Text;
        }

        private void format6Button_Click(object sender, EventArgs e)
        {
            finalNameLabel.Text = format6Button.Text;
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            if (finalNameLabel.Text != "")
            {
                MessageBox.Show(finalNameLabel.Text);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
