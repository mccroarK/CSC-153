﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.helpLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.daysLabel = new System.Windows.Forms.Label();
            this.daysInputTextBox = new System.Windows.Forms.TextBox();
            this.medLabel = new System.Windows.Forms.Label();
            this.medInputTextBox = new System.Windows.Forms.TextBox();
            this.surgeryInput = new System.Windows.Forms.Label();
            this.surgeryInputTextBox = new System.Windows.Forms.TextBox();
            this.labLabel = new System.Windows.Forms.Label();
            this.labInputTextBox = new System.Windows.Forms.TextBox();
            this.rehabLabel = new System.Windows.Forms.Label();
            this.rehabInputTextBox = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // helpLabel
            // 
            this.helpLabel.AutoSize = true;
            this.helpLabel.Location = new System.Drawing.Point(12, 9);
            this.helpLabel.Name = "helpLabel";
            this.helpLabel.Size = new System.Drawing.Size(413, 13);
            this.helpLabel.TabIndex = 3;
            this.helpLabel.Text = "Input the amount of days at a hospital as well as the misc charges to get the tot" +
    "al cost.";
            this.helpLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.rehabLabel);
            this.panel1.Controls.Add(this.rehabInputTextBox);
            this.panel1.Controls.Add(this.labLabel);
            this.panel1.Controls.Add(this.labInputTextBox);
            this.panel1.Controls.Add(this.surgeryInput);
            this.panel1.Controls.Add(this.surgeryInputTextBox);
            this.panel1.Controls.Add(this.medLabel);
            this.panel1.Controls.Add(this.medInputTextBox);
            this.panel1.Controls.Add(this.daysLabel);
            this.panel1.Controls.Add(this.daysInputTextBox);
            this.panel1.Location = new System.Drawing.Point(64, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(295, 136);
            this.panel1.TabIndex = 0;
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(37, 6);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(103, 13);
            this.daysLabel.TabIndex = 5;
            this.daysLabel.Text = "Days at the hospital:";
            this.daysLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // daysInputTextBox
            // 
            this.daysInputTextBox.Location = new System.Drawing.Point(146, 3);
            this.daysInputTextBox.Name = "daysInputTextBox";
            this.daysInputTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysInputTextBox.TabIndex = 0;
            // 
            // medLabel
            // 
            this.medLabel.Location = new System.Drawing.Point(37, 32);
            this.medLabel.Name = "medLabel";
            this.medLabel.Size = new System.Drawing.Size(103, 13);
            this.medLabel.TabIndex = 6;
            this.medLabel.Text = "Medication fee:";
            this.medLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // medInputTextBox
            // 
            this.medInputTextBox.Location = new System.Drawing.Point(146, 29);
            this.medInputTextBox.Name = "medInputTextBox";
            this.medInputTextBox.Size = new System.Drawing.Size(100, 20);
            this.medInputTextBox.TabIndex = 1;
            // 
            // surgeryInput
            // 
            this.surgeryInput.Location = new System.Drawing.Point(37, 58);
            this.surgeryInput.Name = "surgeryInput";
            this.surgeryInput.Size = new System.Drawing.Size(103, 13);
            this.surgeryInput.TabIndex = 7;
            this.surgeryInput.Text = "Surgical fee:";
            this.surgeryInput.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // surgeryInputTextBox
            // 
            this.surgeryInputTextBox.Location = new System.Drawing.Point(146, 55);
            this.surgeryInputTextBox.Name = "surgeryInputTextBox";
            this.surgeryInputTextBox.Size = new System.Drawing.Size(100, 20);
            this.surgeryInputTextBox.TabIndex = 2;
            // 
            // labLabel
            // 
            this.labLabel.Location = new System.Drawing.Point(37, 84);
            this.labLabel.Name = "labLabel";
            this.labLabel.Size = new System.Drawing.Size(103, 13);
            this.labLabel.TabIndex = 8;
            this.labLabel.Text = "Lab fee:";
            this.labLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labInputTextBox
            // 
            this.labInputTextBox.Location = new System.Drawing.Point(146, 81);
            this.labInputTextBox.Name = "labInputTextBox";
            this.labInputTextBox.Size = new System.Drawing.Size(100, 20);
            this.labInputTextBox.TabIndex = 3;
            // 
            // rehabLabel
            // 
            this.rehabLabel.Location = new System.Drawing.Point(37, 110);
            this.rehabLabel.Name = "rehabLabel";
            this.rehabLabel.Size = new System.Drawing.Size(103, 13);
            this.rehabLabel.TabIndex = 9;
            this.rehabLabel.Text = "Rehabilitation fee:";
            this.rehabLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // rehabInputTextBox
            // 
            this.rehabInputTextBox.Location = new System.Drawing.Point(146, 107);
            this.rehabInputTextBox.Name = "rehabInputTextBox";
            this.rehabInputTextBox.Size = new System.Drawing.Size(100, 20);
            this.rehabInputTextBox.TabIndex = 4;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(171, 183);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 1;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(347, 233);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(434, 268);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.helpLabel);
            this.Name = "Form1";
            this.Text = "Hospital Charges";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label helpLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label rehabLabel;
        private System.Windows.Forms.TextBox rehabInputTextBox;
        private System.Windows.Forms.Label labLabel;
        private System.Windows.Forms.TextBox labInputTextBox;
        private System.Windows.Forms.Label surgeryInput;
        private System.Windows.Forms.TextBox surgeryInputTextBox;
        private System.Windows.Forms.Label medLabel;
        private System.Windows.Forms.TextBox medInputTextBox;
        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.TextBox daysInputTextBox;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Button exitButton;
    }
}

