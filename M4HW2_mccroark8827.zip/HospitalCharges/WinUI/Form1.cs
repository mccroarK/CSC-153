﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FuncLibrary;

/**
* 3/20/2023
* CSC 153
* Kevin McCroary
* Takes user input of the cost of hospital fees, then calculates and displays the total.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            // Check input boolean
            bool goodInput = true;

            // Variables
            int daysIn;
            decimal medCharge;
            decimal surgeryCharge;
            decimal labCharge;
            decimal rehabCharge;

            // Check input
            if (!int.TryParse(daysInputTextBox.Text, out daysIn))
            {
                // If day input fails
                goodInput = false;
                daysInputTextBox.Clear();
                daysInputTextBox.Focus();
            }

            if (!decimal.TryParse(medInputTextBox.Text, out medCharge))
            {
                // If medication input fails
                goodInput = false;
                medInputTextBox.Clear();
                medInputTextBox.Focus();
            }

            if (!decimal.TryParse(surgeryInputTextBox.Text, out surgeryCharge))
            {
                // If surgery input fails
                goodInput = false;
                surgeryInputTextBox.Clear();
                surgeryInputTextBox.Focus();
            }

            if (!decimal.TryParse(labInputTextBox.Text, out labCharge))
            {
                // If lab input fails
                goodInput = false;
                labInputTextBox.Clear();
                labInputTextBox.Focus();
            }

            if (!decimal.TryParse(rehabInputTextBox.Text, out rehabCharge))
            {
                // If rehab input fails
                goodInput = false;
                rehabInputTextBox.Clear();
                rehabInputTextBox.Focus();
            }

            // Calculate and display total cost
            if (goodInput)
            {
                MessageBox.Show(Function.CalcTotalCharges(Function.CalcStayCharges(daysIn), Function.CalcMiscCharges(medCharge, surgeryCharge, labCharge, rehabCharge)).ToString("c"));

                // Clear and refocus
                daysInputTextBox.Clear();
                medInputTextBox.Clear();
                surgeryInputTextBox.Clear();
                labInputTextBox.Clear();
                rehabInputTextBox.Clear();

                daysInputTextBox.Focus();
            }
            else
            {
                // If user gives bad input
                MessageBox.Show("Please enter valid input.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close program
            this.Close();
        }
    }
}
