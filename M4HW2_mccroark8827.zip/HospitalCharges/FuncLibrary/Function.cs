﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuncLibrary
{
    public class Function
    {
        // Calculate charge for hospital stay
        public static decimal CalcStayCharges(int days)
        {
            return days * 350m;
        }

        // Calculate medication, surgery, lab, and physical rehab charges
        public static decimal CalcMiscCharges(decimal medication, decimal surgery, decimal lab, decimal rehab)
        {
            return medication + surgery + lab + rehab;
        }

        // Calculate total of stay and misc charges
        public static decimal CalcTotalCharges(decimal stayCharge, decimal miscCharge)
        {
            return stayCharge + miscCharge;
        }
    }
}
