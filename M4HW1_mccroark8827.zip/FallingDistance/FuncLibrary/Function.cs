﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuncLibrary
{
    public class Function
    {
        // Calculate distance travelled function
        public static double FallingDistance(int time)
        {
            // distance = 1/2 * gravity * time^2
            return (0.5) * (9.8) * Math.Pow(time, 2);
        }
    }
}
