﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FuncLibrary;

/*
* 3/15/2023
* CSC 153
* Kevin McCroary
* Calculates the falling distance of an object using user inputted time.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            // Initialize variables
            int fallSeconds;

            // Get user seconds and check input
            if (int.TryParse(timeTextBox.Text, out fallSeconds))
            {
                // Display falling distance
                MessageBox.Show(Function.FallingDistance(fallSeconds).ToString());
            }
            else
            {
                // Display error message
                MessageBox.Show("Please enter a valid input.");
            }

            // Clear and focus
            timeTextBox.Clear();
            timeTextBox.Focus();
        }
    }
}
