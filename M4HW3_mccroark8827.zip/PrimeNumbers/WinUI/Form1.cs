﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FuncLibrary;

/**
* 3/26/2023
* CSC 153
* Kevin McCroary
* Take user inputted integers and check to see if they are prime numbers.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            int num;

            // Check user input
            if (int.TryParse(inputTextBox.Text, out num))
            {
                // If input is good
                if (Function.IsPrime(num))
                {
                    // If the number is prime
                    MessageBox.Show(num + " is a prime number.");
                }
                else
                {
                    // If the number is not prime
                    MessageBox.Show(num + " is NOT a prime number.");
                }
            }
            else
            {
                // If input is bad
                MessageBox.Show("Please enter a proper input value.");
            }

            // Clear and Focus
            inputTextBox.Clear();
            inputTextBox.Focus();
        }
    }
}
