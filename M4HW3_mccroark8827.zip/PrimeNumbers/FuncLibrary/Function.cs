﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuncLibrary
{
    public static class Function
    {
        public static bool IsPrime(int num)
        {
            // Boolean Function
            bool isPrimeNum = false;
            int factorCount = 0;

            // Check number factors
            for (int i = 0; i < num; ++i)
            {
                if ((num % (i+1)) == 0)
                {
                    // Add to number factors
                    ++factorCount;
                }
            }

            // Check if factors are equal to 2
            if (factorCount == 2)
            {
                isPrimeNum = true;
            }

            // Return bool
            return isPrimeNum;
        }
    }
}
