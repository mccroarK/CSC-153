﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.promptLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.wallSquareFeetTextBox = new System.Windows.Forms.TextBox();
            this.paintPricePerGallonTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.estimateButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.totalCostDisplayLabel = new System.Windows.Forms.Label();
            this.laborChargeDisplayLabel = new System.Windows.Forms.Label();
            this.paintCostDisplayLabel = new System.Windows.Forms.Label();
            this.laborHoursDisplayLabel = new System.Windows.Forms.Label();
            this.paintGallonDisplayLabel = new System.Windows.Forms.Label();
            this.paintGallonsIsLabel = new System.Windows.Forms.Label();
            this.laborHoursIsLabel = new System.Windows.Forms.Label();
            this.paintCostIsLabel = new System.Windows.Forms.Label();
            this.laborChargeIsLabel = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // promptLabel
            // 
            this.promptLabel.AutoSize = true;
            this.promptLabel.Location = new System.Drawing.Point(36, 26);
            this.promptLabel.Name = "promptLabel";
            this.promptLabel.Size = new System.Drawing.Size(520, 17);
            this.promptLabel.TabIndex = 0;
            this.promptLabel.Text = "Input the square feet of wall space to be painted and the price of paint per gall" +
    "on.";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(163, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Price of Paint (Per Gallon):";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(163, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Size of Wall (Square Feet):";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // wallSquareFeetTextBox
            // 
            this.wallSquareFeetTextBox.Location = new System.Drawing.Point(347, 82);
            this.wallSquareFeetTextBox.Name = "wallSquareFeetTextBox";
            this.wallSquareFeetTextBox.Size = new System.Drawing.Size(100, 22);
            this.wallSquareFeetTextBox.TabIndex = 0;
            // 
            // paintPricePerGallonTextBox
            // 
            this.paintPricePerGallonTextBox.Location = new System.Drawing.Point(347, 128);
            this.paintPricePerGallonTextBox.Name = "paintPricePerGallonTextBox";
            this.paintPricePerGallonTextBox.Size = new System.Drawing.Size(100, 22);
            this.paintPricePerGallonTextBox.TabIndex = 1;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(510, 487);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // estimateButton
            // 
            this.estimateButton.Location = new System.Drawing.Point(266, 166);
            this.estimateButton.Name = "estimateButton";
            this.estimateButton.Size = new System.Drawing.Size(75, 23);
            this.estimateButton.TabIndex = 2;
            this.estimateButton.Text = "Estimate";
            this.estimateButton.UseVisualStyleBackColor = true;
            this.estimateButton.Click += new System.EventHandler(this.estimateButton_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.totalCostDisplayLabel);
            this.panel1.Controls.Add(this.laborChargeDisplayLabel);
            this.panel1.Controls.Add(this.paintCostDisplayLabel);
            this.panel1.Controls.Add(this.laborHoursDisplayLabel);
            this.panel1.Controls.Add(this.paintGallonDisplayLabel);
            this.panel1.Controls.Add(this.paintGallonsIsLabel);
            this.panel1.Controls.Add(this.laborHoursIsLabel);
            this.panel1.Controls.Add(this.paintCostIsLabel);
            this.panel1.Controls.Add(this.laborChargeIsLabel);
            this.panel1.Controls.Add(this.totalCostLabel);
            this.panel1.Location = new System.Drawing.Point(127, 207);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(348, 235);
            this.panel1.TabIndex = 4;
            // 
            // totalCostDisplayLabel
            // 
            this.totalCostDisplayLabel.BackColor = System.Drawing.Color.White;
            this.totalCostDisplayLabel.Location = new System.Drawing.Point(165, 195);
            this.totalCostDisplayLabel.Name = "totalCostDisplayLabel";
            this.totalCostDisplayLabel.Size = new System.Drawing.Size(115, 23);
            this.totalCostDisplayLabel.TabIndex = 9;
            this.totalCostDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // laborChargeDisplayLabel
            // 
            this.laborChargeDisplayLabel.BackColor = System.Drawing.Color.White;
            this.laborChargeDisplayLabel.Location = new System.Drawing.Point(165, 150);
            this.laborChargeDisplayLabel.Name = "laborChargeDisplayLabel";
            this.laborChargeDisplayLabel.Size = new System.Drawing.Size(115, 23);
            this.laborChargeDisplayLabel.TabIndex = 8;
            this.laborChargeDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // paintCostDisplayLabel
            // 
            this.paintCostDisplayLabel.BackColor = System.Drawing.Color.White;
            this.paintCostDisplayLabel.Location = new System.Drawing.Point(165, 105);
            this.paintCostDisplayLabel.Name = "paintCostDisplayLabel";
            this.paintCostDisplayLabel.Size = new System.Drawing.Size(115, 23);
            this.paintCostDisplayLabel.TabIndex = 7;
            this.paintCostDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // laborHoursDisplayLabel
            // 
            this.laborHoursDisplayLabel.BackColor = System.Drawing.Color.White;
            this.laborHoursDisplayLabel.Location = new System.Drawing.Point(165, 60);
            this.laborHoursDisplayLabel.Name = "laborHoursDisplayLabel";
            this.laborHoursDisplayLabel.Size = new System.Drawing.Size(115, 23);
            this.laborHoursDisplayLabel.TabIndex = 6;
            this.laborHoursDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // paintGallonDisplayLabel
            // 
            this.paintGallonDisplayLabel.BackColor = System.Drawing.Color.White;
            this.paintGallonDisplayLabel.Location = new System.Drawing.Point(165, 15);
            this.paintGallonDisplayLabel.Name = "paintGallonDisplayLabel";
            this.paintGallonDisplayLabel.Size = new System.Drawing.Size(115, 23);
            this.paintGallonDisplayLabel.TabIndex = 5;
            this.paintGallonDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // paintGallonsIsLabel
            // 
            this.paintGallonsIsLabel.Location = new System.Drawing.Point(30, 15);
            this.paintGallonsIsLabel.Name = "paintGallonsIsLabel";
            this.paintGallonsIsLabel.Size = new System.Drawing.Size(115, 23);
            this.paintGallonsIsLabel.TabIndex = 4;
            this.paintGallonsIsLabel.Text = "Paint Gallons:";
            this.paintGallonsIsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // laborHoursIsLabel
            // 
            this.laborHoursIsLabel.Location = new System.Drawing.Point(30, 60);
            this.laborHoursIsLabel.Name = "laborHoursIsLabel";
            this.laborHoursIsLabel.Size = new System.Drawing.Size(115, 23);
            this.laborHoursIsLabel.TabIndex = 3;
            this.laborHoursIsLabel.Text = "Labor Hours:";
            this.laborHoursIsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // paintCostIsLabel
            // 
            this.paintCostIsLabel.Location = new System.Drawing.Point(30, 105);
            this.paintCostIsLabel.Name = "paintCostIsLabel";
            this.paintCostIsLabel.Size = new System.Drawing.Size(115, 23);
            this.paintCostIsLabel.TabIndex = 2;
            this.paintCostIsLabel.Text = "Paint Cost:";
            this.paintCostIsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // laborChargeIsLabel
            // 
            this.laborChargeIsLabel.Location = new System.Drawing.Point(30, 150);
            this.laborChargeIsLabel.Name = "laborChargeIsLabel";
            this.laborChargeIsLabel.Size = new System.Drawing.Size(115, 23);
            this.laborChargeIsLabel.TabIndex = 1;
            this.laborChargeIsLabel.Text = "Labor Charges:";
            this.laborChargeIsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.Location = new System.Drawing.Point(30, 195);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(115, 23);
            this.totalCostLabel.TabIndex = 0;
            this.totalCostLabel.Text = "Total Cost:";
            this.totalCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 522);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.estimateButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.paintPricePerGallonTextBox);
            this.Controls.Add(this.wallSquareFeetTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.promptLabel);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Paint Job Estimator";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label promptLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox wallSquareFeetTextBox;
        private System.Windows.Forms.TextBox paintPricePerGallonTextBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button estimateButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label laborChargeIsLabel;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label paintGallonsIsLabel;
        private System.Windows.Forms.Label laborHoursIsLabel;
        private System.Windows.Forms.Label paintCostIsLabel;
        private System.Windows.Forms.Label totalCostDisplayLabel;
        private System.Windows.Forms.Label laborChargeDisplayLabel;
        private System.Windows.Forms.Label paintCostDisplayLabel;
        private System.Windows.Forms.Label laborHoursDisplayLabel;
        private System.Windows.Forms.Label paintGallonDisplayLabel;
    }
}

