﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 1/25/2023
* CSC 153
* Kevin McCroary
* Program that allows the user to calculate the cost of a paint job
* using the size of wall space and the cost of a gallon of paint.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        const double FEET_PER_HOUR = 14.375;
        const decimal HOURLY_CHARGE = 20.00m;
        const int FEET_PER_GALLON = 115;
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void estimateButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Parse strings to numbers
                double wallSquareFeet = double.Parse(wallSquareFeetTextBox.Text);
                decimal paintPricePerGallon = decimal.Parse(paintPricePerGallonTextBox.Text);

                // Calculate amount of paint gallons needed ROUND UP Math Ceiling
                int paintGallons = (int) Math.Ceiling(wallSquareFeet / FEET_PER_GALLON);

                // Calculate amount of labor hours needed ROUND UP
                int laborHours = (int) Math.Ceiling(wallSquareFeet / FEET_PER_HOUR);

                // Calculate the total cost of the paint gallons
                decimal paintCost = paintPricePerGallon * paintGallons;

                // Calculate the total charge of the labor hours
                decimal laborCharge = HOURLY_CHARGE * laborHours;

                // Calculate the total cost of the job
                decimal totalCost = laborCharge + paintCost;

                // Display variables
                paintGallonDisplayLabel.Text = $"{paintGallons.ToString()} gal";
                laborHoursDisplayLabel.Text = $"{laborHours.ToString()} hours";
                paintCostDisplayLabel.Text = paintCost.ToString("c");
                laborChargeDisplayLabel.Text = laborCharge.ToString("c");
                totalCostDisplayLabel.Text = totalCost.ToString("c");
            }
            catch (Exception ex)
            {
                // Catch if user input is not a number
                MessageBox.Show(ex.Message + " Enter a number >:(");
            }
            // Clear Textboxes
            wallSquareFeetTextBox.Clear();
            paintPricePerGallonTextBox.Clear();
        }
    }
}
