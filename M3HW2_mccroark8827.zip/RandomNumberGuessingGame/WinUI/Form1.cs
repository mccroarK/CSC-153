﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 2/27/2023
* CSC 153
* Kevin McCroary
* Generates a random number from 1-100 for a player to guess.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        Random rand = new Random();
        int answer;
        int winCount;
        int forfeitCount;
        int guessCount;

        public Form1()
        {
            InitializeComponent();

            // Create answer on startup
            answer = rand.Next(0, 99) + 1;
        }

        private void guessButton_Click(object sender, EventArgs e)
        {
            // Guess input variable
            int guessInput;

            // Add to guess count and history
            guessCount += 1;
            guessListBox.Items.Add(guessTextBox.Text);

            // If player has generated a number
            if (int.TryParse(guessTextBox.Text, out guessInput))
            {
                // If player has entered a valid input
                if (guessInput == answer)
                {
                    // Show win message
                    MessageBox.Show($"Congratulations, you won! (Guesses: {guessCount})");

                    // Add to win count
                    winCount += 1;
                    winBox.Text = winCount.ToString();

                    // Generate new random number
                    answer = rand.Next(0, 99) + 1;

                    // Clear guess count and guess history
                    guessCount = 0;
                    guessListBox.Items.Clear();
                }
                else if (guessInput < 1 || guessInput > 100)
                {
                    // Player input is out of range
                    MessageBox.Show("Please stay in range.");
                }
                else if (guessInput < answer)
                {
                    // Player guess is lower than answer
                    MessageBox.Show("Too low, try again.");
                }
                else
                {
                    // Player guess is higher than answer
                    MessageBox.Show("Too high, try again.");
                }
            }
            else
            {
                // If player has entered a bad input
                MessageBox.Show("Please input a valid guess.");
            }

            // Clear and focus guess text box
            guessTextBox.Clear();
            guessTextBox.Focus();
        }

        private void generateButton_Click(object sender, EventArgs e)
        {
            // Generate new random number
            answer = rand.Next(0, 99) + 1;

            // Add forfeit if player already has guesses
            if (guessCount > 0)
            {
                forfeitCount += 1;
                forfeitBox.Text = forfeitCount.ToString();
            }
            
            // Clear guess count and history
            guessCount = 0;
            guessListBox.Items.Clear();

            // Clear and focus guess text box
            guessTextBox.Clear();
            guessTextBox.Focus();
        }

        private void quitButton_Click(object sender, EventArgs e)
        {
            // Close form
            this.Close();
        }
    }
}
