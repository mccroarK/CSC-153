﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guessTextBox = new System.Windows.Forms.TextBox();
            this.promptLabel = new System.Windows.Forms.Label();
            this.guessButton = new System.Windows.Forms.Button();
            this.quitButton = new System.Windows.Forms.Button();
            this.generateButton = new System.Windows.Forms.Button();
            this.guessLabel = new System.Windows.Forms.Label();
            this.winLabel = new System.Windows.Forms.Label();
            this.forfeitLabel = new System.Windows.Forms.Label();
            this.forfeitBox = new System.Windows.Forms.TextBox();
            this.winBox = new System.Windows.Forms.TextBox();
            this.guessListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // guessTextBox
            // 
            this.guessTextBox.Location = new System.Drawing.Point(105, 91);
            this.guessTextBox.Name = "guessTextBox";
            this.guessTextBox.Size = new System.Drawing.Size(123, 22);
            this.guessTextBox.TabIndex = 0;
            // 
            // promptLabel
            // 
            this.promptLabel.AutoSize = true;
            this.promptLabel.Location = new System.Drawing.Point(12, 9);
            this.promptLabel.Name = "promptLabel";
            this.promptLabel.Size = new System.Drawing.Size(216, 17);
            this.promptLabel.TabIndex = 4;
            this.promptLabel.Text = "Guess a random number (1-100)";
            // 
            // guessButton
            // 
            this.guessButton.Location = new System.Drawing.Point(153, 119);
            this.guessButton.Name = "guessButton";
            this.guessButton.Size = new System.Drawing.Size(75, 23);
            this.guessButton.TabIndex = 1;
            this.guessButton.Text = "Guess";
            this.guessButton.UseVisualStyleBackColor = true;
            this.guessButton.Click += new System.EventHandler(this.guessButton_Click);
            // 
            // quitButton
            // 
            this.quitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.quitButton.Location = new System.Drawing.Point(153, 196);
            this.quitButton.Name = "quitButton";
            this.quitButton.Size = new System.Drawing.Size(75, 23);
            this.quitButton.TabIndex = 3;
            this.quitButton.Text = "Quit";
            this.quitButton.UseVisualStyleBackColor = true;
            this.quitButton.Click += new System.EventHandler(this.quitButton_Click);
            // 
            // generateButton
            // 
            this.generateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.generateButton.Location = new System.Drawing.Point(15, 29);
            this.generateButton.Name = "generateButton";
            this.generateButton.Size = new System.Drawing.Size(213, 31);
            this.generateButton.TabIndex = 2;
            this.generateButton.Text = "Generate a new number";
            this.generateButton.UseVisualStyleBackColor = true;
            this.generateButton.Click += new System.EventHandler(this.generateButton_Click);
            // 
            // guessLabel
            // 
            this.guessLabel.AutoSize = true;
            this.guessLabel.Location = new System.Drawing.Point(12, 94);
            this.guessLabel.Name = "guessLabel";
            this.guessLabel.Size = new System.Drawing.Size(87, 17);
            this.guessLabel.TabIndex = 5;
            this.guessLabel.Text = "Your Guess:";
            // 
            // winLabel
            // 
            this.winLabel.Location = new System.Drawing.Point(12, 171);
            this.winLabel.Name = "winLabel";
            this.winLabel.Size = new System.Drawing.Size(59, 23);
            this.winLabel.TabIndex = 6;
            this.winLabel.Text = "Wins:";
            this.winLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // forfeitLabel
            // 
            this.forfeitLabel.AutoSize = true;
            this.forfeitLabel.Location = new System.Drawing.Point(12, 199);
            this.forfeitLabel.Name = "forfeitLabel";
            this.forfeitLabel.Size = new System.Drawing.Size(59, 17);
            this.forfeitLabel.TabIndex = 7;
            this.forfeitLabel.Text = "Forfeits:";
            // 
            // forfeitBox
            // 
            this.forfeitBox.Location = new System.Drawing.Point(77, 196);
            this.forfeitBox.Name = "forfeitBox";
            this.forfeitBox.ReadOnly = true;
            this.forfeitBox.Size = new System.Drawing.Size(37, 22);
            this.forfeitBox.TabIndex = 9;
            // 
            // winBox
            // 
            this.winBox.Location = new System.Drawing.Point(77, 168);
            this.winBox.Name = "winBox";
            this.winBox.ReadOnly = true;
            this.winBox.Size = new System.Drawing.Size(37, 22);
            this.winBox.TabIndex = 8;
            // 
            // guessListBox
            // 
            this.guessListBox.FormattingEnabled = true;
            this.guessListBox.ItemHeight = 16;
            this.guessListBox.Location = new System.Drawing.Point(234, 9);
            this.guessListBox.Name = "guessListBox";
            this.guessListBox.Size = new System.Drawing.Size(139, 212);
            this.guessListBox.TabIndex = 10;
            // 
            // Form1
            // 
            this.AcceptButton = this.guessButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.quitButton;
            this.ClientSize = new System.Drawing.Size(385, 231);
            this.Controls.Add(this.guessListBox);
            this.Controls.Add(this.winBox);
            this.Controls.Add(this.forfeitBox);
            this.Controls.Add(this.forfeitLabel);
            this.Controls.Add(this.winLabel);
            this.Controls.Add(this.guessLabel);
            this.Controls.Add(this.generateButton);
            this.Controls.Add(this.quitButton);
            this.Controls.Add(this.guessButton);
            this.Controls.Add(this.promptLabel);
            this.Controls.Add(this.guessTextBox);
            this.Name = "Form1";
            this.Text = "Random Number Guessing Game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox guessTextBox;
        private System.Windows.Forms.Label promptLabel;
        private System.Windows.Forms.Button guessButton;
        private System.Windows.Forms.Button quitButton;
        private System.Windows.Forms.Button generateButton;
        private System.Windows.Forms.Label guessLabel;
        private System.Windows.Forms.Label winLabel;
        private System.Windows.Forms.Label forfeitLabel;
        private System.Windows.Forms.TextBox forfeitBox;
        private System.Windows.Forms.TextBox winBox;
        private System.Windows.Forms.ListBox guessListBox;
    }
}

