﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/**
* 3/6/2023
* CSC 153
* Kevin McCroary
* Program that creates a file with random numbers between 1-100. The amount of numbers in the file depends on user input.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void createButton_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            StreamWriter outputFile;
            int numAmount;

            // Route initial directory to desktop
            saveFile.InitialDirectory = "C:/../../Desktop";

            // Check if user input is valid
            if (int.TryParse(inputTextBox.Text, out numAmount))
            {
                if (saveFile.ShowDialog() == DialogResult.OK)
                {
                    // Create or override file
                    outputFile = File.CreateText(saveFile.FileName);

                    // Write random numbers into file
                    for (int i = 0; i < numAmount; i++)
                    {
                        outputFile.WriteLine((rand.Next(0, 99) + 1).ToString());
                    }

                    // Close file
                    outputFile.Close();
                }
            }
            else
            {
                // If user enters bad input
                MessageBox.Show("Please enter a valid integer.");
            }

            // Clear and focus input textbox
            inputTextBox.Clear();
            inputTextBox.Focus();
        }
    }
}
