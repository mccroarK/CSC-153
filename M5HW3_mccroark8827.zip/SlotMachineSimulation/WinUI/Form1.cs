﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HelperLibrary;

/**
* 4/19/2023
* CSC 153
* Kevin McCroary
* Allow users to enter money and see how much they can earn by simulating a slot machine
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        List<PictureBox> slotList;
        List<int> indexList;
        decimal totalEntered;
        decimal totalEarned;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Display total money entered and total money earned
            MessageBox.Show($"Total Entered: {totalEntered.ToString("c")}\tTotal Earned: {totalEarned.ToString("c")}");
            // Close the program
            this.Close();
        }

        private void spinButton_Click(object sender, EventArgs e)
        {
            decimal moneyEntered;
            if (decimal.TryParse(inputTextBox.Text, out moneyEntered))
            {
                // If user inputs a valid amount of money
                totalEntered += moneyEntered;
                
                indexList = HelperLibrary.SlotHandler.Spin(slotList.Count, fruitList.Images.Count); // List to hold index of slot images

                ChangeSlots();

                int multiplier = HelperLibrary.SlotHandler.Check(indexList);
                totalEarned += moneyEntered * multiplier;

                // Display results
                if (multiplier == 0)
                {
                    MessageBox.Show("You earned $0");
                }
                else
                {
                    MessageBox.Show($"You earned {multiplier} times the money entered ({(moneyEntered * multiplier).ToString("c")})");
                }
            }
            else
            {
                // If user's input is invalid
                MessageBox.Show("Invalid input");
            }

            // Clear and focus input text box
            inputTextBox.Clear();
            inputTextBox.Focus();
        }

        void ChangeSlots()
        {
            // Change slot images
            for (int i = 0; i < slotList.Count; i++)
            {
                slotList[i].Image = fruitList.Images[indexList[i]];
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            slotList = new List<PictureBox>() { slotBox1, slotBox2, slotBox3 };
            indexList = new List<int>() { 0, 0, 0 };

            ChangeSlots();

            indexList.Clear();
        }
    }
}
