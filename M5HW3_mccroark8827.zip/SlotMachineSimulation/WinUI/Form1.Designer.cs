﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.slotBox1 = new System.Windows.Forms.PictureBox();
            this.slotBox2 = new System.Windows.Forms.PictureBox();
            this.slotBox3 = new System.Windows.Forms.PictureBox();
            this.instructLabel = new System.Windows.Forms.Label();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.spinButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.fruitList = new System.Windows.Forms.ImageList(this.components);
            this.helpLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.slotBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // slotBox1
            // 
            this.slotBox1.Location = new System.Drawing.Point(12, 29);
            this.slotBox1.Name = "slotBox1";
            this.slotBox1.Size = new System.Drawing.Size(128, 128);
            this.slotBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.slotBox1.TabIndex = 0;
            this.slotBox1.TabStop = false;
            // 
            // slotBox2
            // 
            this.slotBox2.Location = new System.Drawing.Point(146, 29);
            this.slotBox2.Name = "slotBox2";
            this.slotBox2.Size = new System.Drawing.Size(128, 128);
            this.slotBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.slotBox2.TabIndex = 1;
            this.slotBox2.TabStop = false;
            // 
            // slotBox3
            // 
            this.slotBox3.Location = new System.Drawing.Point(280, 29);
            this.slotBox3.Name = "slotBox3";
            this.slotBox3.Size = new System.Drawing.Size(128, 128);
            this.slotBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.slotBox3.TabIndex = 2;
            this.slotBox3.TabStop = false;
            // 
            // instructLabel
            // 
            this.instructLabel.AutoSize = true;
            this.instructLabel.Location = new System.Drawing.Point(85, 190);
            this.instructLabel.Name = "instructLabel";
            this.instructLabel.Size = new System.Drawing.Size(127, 17);
            this.instructLabel.TabIndex = 4;
            this.instructLabel.Text = "Amount Inserted: $";
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(218, 187);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(100, 22);
            this.inputTextBox.TabIndex = 0;
            // 
            // spinButton
            // 
            this.spinButton.Location = new System.Drawing.Point(88, 230);
            this.spinButton.Name = "spinButton";
            this.spinButton.Size = new System.Drawing.Size(102, 28);
            this.spinButton.TabIndex = 1;
            this.spinButton.Text = "Spin";
            this.spinButton.UseVisualStyleBackColor = true;
            this.spinButton.Click += new System.EventHandler(this.spinButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(216, 230);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(102, 28);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // fruitList
            // 
            this.fruitList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("fruitList.ImageStream")));
            this.fruitList.TransparentColor = System.Drawing.Color.Transparent;
            this.fruitList.Images.SetKeyName(0, "Apple.bmp");
            this.fruitList.Images.SetKeyName(1, "Banana.bmp");
            this.fruitList.Images.SetKeyName(2, "Cherries.bmp");
            this.fruitList.Images.SetKeyName(3, "Grapes.bmp");
            this.fruitList.Images.SetKeyName(4, "Lemon.bmp");
            this.fruitList.Images.SetKeyName(5, "Lime.bmp");
            this.fruitList.Images.SetKeyName(6, "Orange.bmp");
            this.fruitList.Images.SetKeyName(7, "Pear.bmp");
            this.fruitList.Images.SetKeyName(8, "Strawberry.bmp");
            this.fruitList.Images.SetKeyName(9, "Watermelon.bmp");
            // 
            // helpLabel
            // 
            this.helpLabel.AutoSize = true;
            this.helpLabel.Location = new System.Drawing.Point(73, 9);
            this.helpLabel.Name = "helpLabel";
            this.helpLabel.Size = new System.Drawing.Size(282, 17);
            this.helpLabel.TabIndex = 3;
            this.helpLabel.Text = "Enter money and spin to see if you can win.";
            // 
            // Form1
            // 
            this.AcceptButton = this.spinButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(421, 279);
            this.Controls.Add(this.helpLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.spinButton);
            this.Controls.Add(this.inputTextBox);
            this.Controls.Add(this.instructLabel);
            this.Controls.Add(this.slotBox3);
            this.Controls.Add(this.slotBox2);
            this.Controls.Add(this.slotBox1);
            this.Name = "Form1";
            this.Text = "Slot Machine Simulation";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.slotBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox slotBox1;
        private System.Windows.Forms.PictureBox slotBox2;
        private System.Windows.Forms.PictureBox slotBox3;
        private System.Windows.Forms.Label instructLabel;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.Button spinButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ImageList fruitList;
        private System.Windows.Forms.Label helpLabel;
    }
}

