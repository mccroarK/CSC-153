﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLibrary
{
    public static class SlotHandler
    {
        static Random rand = new Random();

        public static List<int> Spin(int slotAmount, int imageAmount)
        {
            // Create a list of indexes to use for slot images
            List<int> imageIndexes = new List<int>();

            // For the amount of slots on the machine
            for (int i = 0; i < slotAmount; i++)
            {
                // Add a number between 0 and the amount of different images that a slot can display
                imageIndexes.Add(rand.Next(imageAmount));
            }

            return imageIndexes;
        }

        public static int Check(List<int> indexList)
        {
            // Check the indexes of the slots for matches
            int matchCount = 0;
            int matchHighest = 0;

            for (int i = 0; i < indexList.Count; i++)
            {
                matchCount = 0;
                for (int j = 0; j < indexList.Count; j++)
                {
                    if (indexList[i] == indexList[j])
                    {
                        matchCount++;
                    }
                }
                matchHighest = matchCount > matchHighest ? matchCount : matchHighest;
            }

            matchHighest = matchHighest != 1 ? matchHighest : 0;
            return matchHighest;
        }
    }
}
