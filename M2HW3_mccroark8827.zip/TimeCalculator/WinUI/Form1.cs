﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 2/6/2023
* CSC 153
* Kevin McCroary
* Calculates how much time passes using user inputted seconds.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        // Capitalized constants this time. Sorry, I get rusty fast.
        private const int SEC_IN_MINUTE = 60;
        private const int SEC_IN_HOUR = 3600;
        private const int SEC_IN_DAY = 86400;
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            int seconds, minutes, hours, days;
            bool minutePass = false;
            bool hourPass = false;
            bool dayPass = false;
            string timeString = "";

            if (int.TryParse(secondsInputTextBox.Text, out seconds))
            {
                if (seconds >= SEC_IN_DAY)
                {
                    dayPass = true;
                    days = seconds / SEC_IN_DAY;
                    seconds = seconds % SEC_IN_DAY;
                    if (days > 1)
                    {
                        timeString += $"{days} days";
                    }
                    else
                    {
                        timeString += $"{days} day";
                    }
                }

                if (seconds >= SEC_IN_HOUR)
                {
                    hourPass = true;
                    hours = seconds / SEC_IN_HOUR;
                    seconds = seconds % SEC_IN_HOUR;

                    if (dayPass)
                        timeString += ", ";

                    if (hours > 1)
                    {
                        timeString += $"{hours} hours";
                    }
                    else
                    {
                        timeString += $"{hours} hour";
                    }
                }

                if (seconds >= SEC_IN_MINUTE)
                {
                    minutePass = true;
                    minutes = seconds / SEC_IN_MINUTE;
                    seconds = seconds % SEC_IN_MINUTE;
                    
                    if (hourPass)
                        timeString += ", ";
                    
                    if (minutes > 1)
                    {
                        timeString += $"{minutes} minutes";
                    }
                    else
                    {
                        timeString += $"{minutes} minute";
                    }
                }

                if (seconds > 0)
                {
                    if (minutePass)
                        timeString += ", ";

                    if (seconds > 1)
                    {
                        timeString += $"{seconds} seconds";
                    }
                    else if (seconds == 1)
                    {
                        timeString += $"{seconds} second";
                    }
                }

                MessageBox.Show(timeString);
                secondsInputTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Please enter valid input.");
                secondsInputTextBox.Clear();
            }
        }
    }
}
