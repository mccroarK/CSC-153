﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("My name is Kevin McCroary.");
            Console.WriteLine("I want to get familiar with programming in C#.");
            Console.WriteLine("I have taken CSC-151, CIS-115, and CTI-110");
            Console.WriteLine("Lists, dictionaries, and classes were not covered in the JAVA class.");
            Console.ReadLine();
        }
    }
}
