﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DLE_ClassLibrary
{
    public static class AnswerLoader
    {
        public static char[] Load(StreamReader inputFile,int question_count)
        {
            int index = 0; // Index for while loop
            char[] userAnswers = new char[question_count]; // Array containing characters for user's answer

            {
                // Fill array with user's answers
                while (index < question_count && !inputFile.EndOfStream)
                {
                    // Get line as string then split or add to userAnswer
                    try
                    {
                        userAnswers[index] = inputFile.ReadLine()[0];
                    }
                    catch
                    {
                        userAnswers[index] = 'F'; // Unanswered
                    }   

                    index++;
                }
            }
            return userAnswers; // Return array containing user's answers
        }
    }
}
