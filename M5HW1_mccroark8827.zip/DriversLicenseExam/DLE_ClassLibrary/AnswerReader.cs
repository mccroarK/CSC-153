﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DLE_ClassLibrary
{
    public static class AnswerReader
    {
        public static List<int> Compare(char[] testAnswers, char[] userAnswers)
        {
            List<int> incorrectQuestions = new List<int>(); // Count of correct answers

            // For the amount of answers in the test
            for (int i = 0; i < testAnswers.Length; i++)
            {
                // Check if user answer is the same as the test answer
                if (Char.ToLower(userAnswers[i]) != Char.ToLower(testAnswers[i]))
                {
                    incorrectQuestions.Add((i + 1)); // Add number of incorrect question
                }
            }

            return incorrectQuestions;
        }
    }
}
