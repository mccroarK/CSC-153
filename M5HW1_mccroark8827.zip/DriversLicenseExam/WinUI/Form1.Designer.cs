﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.openFileButton = new System.Windows.Forms.Button();
            this.correctLabel = new System.Windows.Forms.Label();
            this.incorrectLabel = new System.Windows.Forms.Label();
            this.questionShowListBox = new System.Windows.Forms.ListBox();
            this.correctShowLabel = new System.Windows.Forms.Label();
            this.incorrectShowLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.missedLabel = new System.Windows.Forms.Label();
            this.instructLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // openFile
            // 
            this.openFile.FileName = "Answers";
            this.openFile.Filter = "Text files|*.txt";
            // 
            // openFileButton
            // 
            this.openFileButton.Location = new System.Drawing.Point(114, 67);
            this.openFileButton.Name = "openFileButton";
            this.openFileButton.Size = new System.Drawing.Size(90, 27);
            this.openFileButton.TabIndex = 0;
            this.openFileButton.Text = "Open File";
            this.openFileButton.UseVisualStyleBackColor = true;
            this.openFileButton.Click += new System.EventHandler(this.openFileButton_Click);
            // 
            // correctLabel
            // 
            this.correctLabel.Location = new System.Drawing.Point(80, 111);
            this.correctLabel.Name = "correctLabel";
            this.correctLabel.Size = new System.Drawing.Size(124, 17);
            this.correctLabel.TabIndex = 5;
            this.correctLabel.Text = "Correct Answers:";
            this.correctLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // incorrectLabel
            // 
            this.incorrectLabel.Location = new System.Drawing.Point(80, 150);
            this.incorrectLabel.Name = "incorrectLabel";
            this.incorrectLabel.Size = new System.Drawing.Size(124, 17);
            this.incorrectLabel.TabIndex = 6;
            this.incorrectLabel.Text = "Incorrect Answers:";
            this.incorrectLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // questionShowListBox
            // 
            this.questionShowListBox.FormattingEnabled = true;
            this.questionShowListBox.ItemHeight = 16;
            this.questionShowListBox.Location = new System.Drawing.Point(103, 211);
            this.questionShowListBox.Name = "questionShowListBox";
            this.questionShowListBox.Size = new System.Drawing.Size(120, 116);
            this.questionShowListBox.TabIndex = 4;
            // 
            // correctShowLabel
            // 
            this.correctShowLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.correctShowLabel.Location = new System.Drawing.Point(210, 111);
            this.correctShowLabel.Name = "correctShowLabel";
            this.correctShowLabel.Size = new System.Drawing.Size(48, 19);
            this.correctShowLabel.TabIndex = 2;
            // 
            // incorrectShowLabel
            // 
            this.incorrectShowLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.incorrectShowLabel.Location = new System.Drawing.Point(210, 150);
            this.incorrectShowLabel.Name = "incorrectShowLabel";
            this.incorrectShowLabel.Size = new System.Drawing.Size(48, 19);
            this.incorrectShowLabel.TabIndex = 3;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(246, 328);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // missedLabel
            // 
            this.missedLabel.AutoSize = true;
            this.missedLabel.Location = new System.Drawing.Point(100, 191);
            this.missedLabel.Name = "missedLabel";
            this.missedLabel.Size = new System.Drawing.Size(93, 17);
            this.missedLabel.TabIndex = 7;
            this.missedLabel.Text = "You Missed #";
            // 
            // instructLabel
            // 
            this.instructLabel.Location = new System.Drawing.Point(12, 26);
            this.instructLabel.Name = "instructLabel";
            this.instructLabel.Size = new System.Drawing.Size(309, 38);
            this.instructLabel.TabIndex = 8;
            this.instructLabel.Text = " Place your answers to the Driver\'s License Exam to get the score. (One letter pe" +
    "r line)";
            this.instructLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(80, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(168, 17);
            this.titleLabel.TabIndex = 9;
            this.titleLabel.Text = "Driver\'s License Exam";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 363);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.instructLabel);
            this.Controls.Add(this.missedLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.incorrectShowLabel);
            this.Controls.Add(this.correctShowLabel);
            this.Controls.Add(this.questionShowListBox);
            this.Controls.Add(this.incorrectLabel);
            this.Controls.Add(this.correctLabel);
            this.Controls.Add(this.openFileButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFile;
        private System.Windows.Forms.Button openFileButton;
        private System.Windows.Forms.Label correctLabel;
        private System.Windows.Forms.Label incorrectLabel;
        private System.Windows.Forms.ListBox questionShowListBox;
        private System.Windows.Forms.Label correctShowLabel;
        private System.Windows.Forms.Label incorrectShowLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label missedLabel;
        private System.Windows.Forms.Label instructLabel;
        private System.Windows.Forms.Label titleLabel;
    }
}

