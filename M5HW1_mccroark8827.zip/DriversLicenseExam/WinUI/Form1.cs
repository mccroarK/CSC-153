﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using DLE_ClassLibrary;

/*
* 4/5/2023
* CSC 153
* Kevin McCroary
* Gets a text answer document from the user and scores how well they did on the Driver's License Exam.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        const int QUESTION_COUNT = 20;
        char[] testAnswers = 
            { 'B', 'D', 'A', 'A', 'C', 
            'A', 'B', 'A', 'C', 'D',
            'B', 'C', 'D', 'A', 'D',
            'C', 'C', 'B', 'D', 'A'};

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DisplayQuestionList(List<int> questionNumbers)
        {
            // Add incorrect question numbers to List Box
            foreach (int number in questionNumbers)
            {
                questionShowListBox.Items.Add(number);
            }
        }

        private void openFileButton_Click(object sender, EventArgs e)
        {
            StreamReader inputFile;
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Open the file that user chooses
                    inputFile = File.OpenText(openFile.FileName);

                    // Get character array with user's answers
                    char[] userAnswers = AnswerLoader.Load(inputFile, QUESTION_COUNT);

                    // Close the file
                    inputFile.Close();

                    // Find the numbers of incorrect questions
                    List<int> incorrectQuestions = AnswerReader.Compare(testAnswers, userAnswers);

                    // Get amount correct and incorrect answers from user's test
                    int incorrectCount = incorrectQuestions.Count;
                    int correctCount = QUESTION_COUNT - incorrectCount;

                    // Display incorrect question numbers and amount of correct and incorrect answers
                    correctShowLabel.Text = correctCount.ToString(); // Correct question amount
                    incorrectShowLabel.Text = incorrectCount.ToString(); // Incorrect question amount
                    DisplayQuestionList(incorrectQuestions); // Incorrect question numbers
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
