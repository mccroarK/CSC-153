﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/**
* 3/6/2023
* CSC 153
* Kevin McCroary
* Takes the file made from the Random Number File Writer and displays the contents as well as the amount and sum of the numbers.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void readButton_Click(object sender, EventArgs e)
        {
            StreamReader inputFile;

            // Clear variables and list
            int numTotal = 0;
            numListBox.Items.Clear();

            // Open file that user selects
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Open text file
                    inputFile = File.OpenText(openFile.FileName);

                    // Read file
                    while (!inputFile.EndOfStream)
                    {
                        // Stores numbers from file
                        string numVar = inputFile.ReadLine();

                        // Add numbers to list
                        numListBox.Items.Add(numVar);

                        // Add number to total
                        numTotal += int.Parse(numVar);
                    }

                    // Display variables
                    totalTextBox.Text = numTotal.ToString();
                    countTextBox.Text = numListBox.Items.Count.ToString();
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
