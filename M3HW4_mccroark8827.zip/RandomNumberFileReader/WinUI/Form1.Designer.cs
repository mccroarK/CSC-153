﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.readButton = new System.Windows.Forms.Button();
            this.numListBox = new System.Windows.Forms.ListBox();
            this.countLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.countTextBox = new System.Windows.Forms.TextBox();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.descLabel = new System.Windows.Forms.Label();
            this.instructLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // readButton
            // 
            this.readButton.Location = new System.Drawing.Point(217, 90);
            this.readButton.Name = "readButton";
            this.readButton.Size = new System.Drawing.Size(75, 23);
            this.readButton.TabIndex = 0;
            this.readButton.Text = "Read";
            this.readButton.UseVisualStyleBackColor = true;
            this.readButton.Click += new System.EventHandler(this.readButton_Click);
            // 
            // numListBox
            // 
            this.numListBox.FormattingEnabled = true;
            this.numListBox.ItemHeight = 16;
            this.numListBox.Location = new System.Drawing.Point(12, 139);
            this.numListBox.Name = "numListBox";
            this.numListBox.Size = new System.Drawing.Size(289, 164);
            this.numListBox.TabIndex = 4;
            // 
            // countLabel
            // 
            this.countLabel.Location = new System.Drawing.Point(307, 142);
            this.countLabel.Name = "countLabel";
            this.countLabel.Size = new System.Drawing.Size(119, 26);
            this.countLabel.TabIndex = 5;
            this.countLabel.Text = "Number Amount:";
            this.countLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // totalLabel
            // 
            this.totalLabel.Location = new System.Drawing.Point(307, 168);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(119, 26);
            this.totalLabel.TabIndex = 6;
            this.totalLabel.Text = "Number Total:";
            this.totalLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(416, 280);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // openFile
            // 
            this.openFile.FileName = "numbers.txt";
            this.openFile.Title = "Open file";
            // 
            // countTextBox
            // 
            this.countTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.countTextBox.Location = new System.Drawing.Point(432, 139);
            this.countTextBox.Name = "countTextBox";
            this.countTextBox.ReadOnly = true;
            this.countTextBox.Size = new System.Drawing.Size(59, 22);
            this.countTextBox.TabIndex = 7;
            // 
            // totalTextBox
            // 
            this.totalTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalTextBox.Location = new System.Drawing.Point(432, 165);
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.ReadOnly = true;
            this.totalTextBox.Size = new System.Drawing.Size(59, 22);
            this.totalTextBox.TabIndex = 8;
            // 
            // descLabel
            // 
            this.descLabel.Location = new System.Drawing.Point(12, 9);
            this.descLabel.Name = "descLabel";
            this.descLabel.Size = new System.Drawing.Size(479, 44);
            this.descLabel.TabIndex = 2;
            this.descLabel.Text = "Takes the file made from the Random Number File Writer and displays the values, t" +
    "he number amount, and the totals of the numbers";
            this.descLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // instructLabel
            // 
            this.instructLabel.AutoSize = true;
            this.instructLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructLabel.Location = new System.Drawing.Point(171, 70);
            this.instructLabel.Name = "instructLabel";
            this.instructLabel.Size = new System.Drawing.Size(165, 17);
            this.instructLabel.TabIndex = 3;
            this.instructLabel.Text = "Select the file to read";
            // 
            // Form1
            // 
            this.AcceptButton = this.readButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(503, 319);
            this.Controls.Add(this.instructLabel);
            this.Controls.Add(this.descLabel);
            this.Controls.Add(this.totalTextBox);
            this.Controls.Add(this.countTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.countLabel);
            this.Controls.Add(this.numListBox);
            this.Controls.Add(this.readButton);
            this.Name = "Form1";
            this.Text = "Random Number File Reader";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button readButton;
        private System.Windows.Forms.ListBox numListBox;
        private System.Windows.Forms.Label countLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.OpenFileDialog openFile;
        private System.Windows.Forms.TextBox countTextBox;
        private System.Windows.Forms.TextBox totalTextBox;
        private System.Windows.Forms.Label descLabel;
        private System.Windows.Forms.Label instructLabel;
    }
}

